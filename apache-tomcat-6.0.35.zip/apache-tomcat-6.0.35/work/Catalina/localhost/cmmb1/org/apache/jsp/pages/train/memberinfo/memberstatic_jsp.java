package org.apache.jsp.pages.train.memberinfo;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.labels.StandardCategoryItemLabelGenerator;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.LineAndShapeRenderer;
import org.jfree.chart.title.TextTitle;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.general.DatasetUtilities;
import org.jfree.ui.RectangleInsets;
import org.jfree.chart.labels.ItemLabelAnchor;
import org.jfree.chart.labels.ItemLabelPosition;
import org.jfree.ui.TextAnchor;
import org.jfree.chart.ChartRenderingInfo;
import org.jfree.chart.entity.StandardEntityCollection;
import java.awt.Color;
import java.util.*;
import java.awt.Font;
import java.text.DecimalFormat;
import com.wootion.cmmb.view.utils.MyChartUtility;

public final class memberstatic_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();

  private static java.util.List _jspx_dependants;

  static {
    _jspx_dependants = new java.util.ArrayList(1);
    _jspx_dependants.add("/pages/train/memberinfo/../import.jsp");
  }

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.AnnotationProcessor _jsp_annotationprocessor;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_annotationprocessor = (org.apache.AnnotationProcessor) getServletConfig().getServletContext().getAttribute(org.apache.AnnotationProcessor.class.getName());
  }

  public void _jspDestroy() {
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      response.setContentType("text/html;charset=UTF-8");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");

  /***********基础数据*****************/
  List<String> marks = (ArrayList<String>)request.getAttribute("data");
  String[] m1=marks.get(0).split(",");
  String[] md=marks.get(1).split(",");
  //String[] mn=marks.get(2).split(",");
  double[][] data = new double[3][md.length];
  for(int i=0;i<3;i++){
     for(int j=0;j<data[i].length;j++){
          data[i][j]=Double.parseDouble(m1[j+(i*md.length)]);
     }
  }
  
  //给值
  String[] columnKeys=new String[md.length];
  for(int i=0;i<columnKeys.length;i++){
      //columnKeys[i]=md[i]+"\n("+mn[i]+")";
      columnKeys[i]=md[i];
  }
  
  String[] rowKeys = { "健康评估IADL分数", "健康评估ADL分数","血糖"};
  String chartTitle = "会员健康评估";
  String xName = "日期";
  String yName = "分数";
  int width = 230*md.length;
  int height = 330;
  /*******************************/

  CategoryDataset dataset = DatasetUtilities.createCategoryDataset(rowKeys, columnKeys, data);

  JFreeChart chart = ChartFactory.createLineChart(chartTitle, // 图表标题
      xName, // 目录轴的显示标签
      yName, // 数值轴的显示标签
      dataset, // 数据集
      PlotOrientation.VERTICAL, // 图表方向：水平、垂直
      true, // 是否显示图例(对于简单的柱状图必须是false)
      false, // 是否生成工具
      false // 是否生成URL链接
      );

  chart.setTextAntiAlias(false);

  TextTitle title = new TextTitle(chartTitle);
  title.setFont(new Font("隶书", Font.BOLD, 25));
  chart.setTitle(title);// 设置图标题的字体重新设置title

  chart.getLegend().setItemFont(new Font("SansSerif", Font.BOLD, 12));// 图例显示格式

  chart.setBackgroundPaint(Color.WHITE);//设置背景颜色
  chart.setBorderVisible(true);//设置背景边框

  CategoryPlot categoryplot = (CategoryPlot) chart.getPlot();//获取图表

  categoryplot.setDomainGridlinesVisible(true);// x轴网格是否可见

  categoryplot.setRangeGridlinesVisible(true); // y轴网格是否可见

  categoryplot.setRangeGridlinePaint(Color.WHITE);// 虚线色彩

  categoryplot.setDomainGridlinePaint(Color.WHITE);// 虚线色彩

  categoryplot.setBackgroundPaint(Color.lightGray);//设定图表数据显示部分背景色

  categoryplot.setAxisOffset(new RectangleInsets(5D, 5D, 5D, 5D)); // 设置轴和面板之间的距离 参数1：上距 参数2：左距 参数3：下距 参数4：右距

  CategoryAxis domainAxis = categoryplot.getDomainAxis();//横轴
  domainAxis.setLabelFont(new Font("SansSerif", Font.TRUETYPE_FONT, 11));// 轴标题
  domainAxis.setTickLabelFont(new Font("SansSerif", Font.TRUETYPE_FONT, 11));// 轴数值
  //domainAxis.setCategoryLabelPositions(CategoryLabelPositions.UP_45); // 横轴上的Lable 45度倾斜
  domainAxis.setLowerMargin(0.0);// 设置距离图片左端距离
  domainAxis.setUpperMargin(0.0);// 设置距离图片右端距离
  domainAxis.setMaximumCategoryLabelLines(4);  //设置最大显示行数

  ValueAxis rangeAxis = categoryplot.getRangeAxis(); //纵轴  
  rangeAxis.setLabelFont(new Font("SansSerif", Font.TRUETYPE_FONT, 11));// 轴标题
  rangeAxis.setTickLabelFont(new Font("SansSerif", Font.TRUETYPE_FONT, 11));// 轴数值
  rangeAxis.setRange(0, 120);//纵轴显示范围
  rangeAxis.setAutoTickUnitSelection(true);

  rangeAxis.setLowerMargin(5);// 设置距离图片下端距离
  rangeAxis.setUpperMargin(0.5);// 设置距离图片上端距离

  NumberAxis numberaxis = (NumberAxis) categoryplot.getRangeAxis();
  numberaxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
  numberaxis.setAutoRangeIncludesZero(true);
  numberaxis.setUpperMargin(1.15); // 设置最高的一个 Item 与图片顶端的距离
  numberaxis.setLowerMargin(0.15);// 设置最低的一个 Item 与图片底端的距离
  DecimalFormat df = new DecimalFormat("#0.00");
  numberaxis.setNumberFormatOverride(df); //设置纵轴精度

  categoryplot.setRangeAxis(numberaxis);

  LineAndShapeRenderer lineandshaperenderer = (LineAndShapeRenderer) categoryplot.getRenderer();// 获得renderer

  lineandshaperenderer.setBaseShapesVisible(true); // 点（即数据点）可见

  lineandshaperenderer.setBaseItemLabelGenerator(new StandardCategoryItemLabelGenerator());
  lineandshaperenderer.setBaseItemLabelsVisible(true);// 显示折点数据
  lineandshaperenderer.setBaseItemLabelFont(new Font("SansSerif", Font.TRUETYPE_FONT, 12));// 折点数据字体
  lineandshaperenderer.setBasePositiveItemLabelPosition(new ItemLabelPosition(ItemLabelAnchor.OUTSIDE10,
      TextAnchor.BASELINE_CENTER));//这点数据显示位置

  lineandshaperenderer.setBaseLinesVisible(true); // 点（即数据点）间有连线可见

  ChartRenderingInfo info = new ChartRenderingInfo(new StandardEntityCollection());

  String filename = MyChartUtility.saveMyChartAsPNG(chart, width, height, info, session);

  String graphURL = request.getContextPath() + "/servlet/DisplayChart?filename=" + filename;

      out.write('\r');
      out.write('\n');
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");

String path = request.getContextPath();
String basePath = request.getScheme()+"://"+request.getServerName()+":"+request.getServerPort()+path;

      out.write("\r\n");
      out.write("<link href=\"");
      out.print(basePath);
      out.write("/pages/train/skins/css/common.css\" rel=\"stylesheet\" type=\"text/css\" />\r\n");
      out.write("<script type=\"text/javascript\" src=\"");
      out.print(basePath);
      out.write("/js/md5.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\" src=\"");
      out.print(basePath);
      out.write("/js/jquery-1.3.2.min.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\" src=\"");
      out.print(basePath);
      out.write("/pages/train/js/check.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\" src=\"");
      out.print(basePath);
      out.write("/pages/train/js/LodopFuncs.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\" src=\"");
      out.print(basePath);
      out.write("/js/My97DatePicker/WdatePicker.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\" src=\"");
      out.print(basePath);
      out.write("/pages/train/js/common.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\" src=\"");
      out.print(basePath);
      out.write("/js/communication.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\" src=\"");
      out.print(basePath);
      out.write("/js/validate.js\"></script>\r\n");
      out.write("\r\n");
      out.write("<HTML>\r\n");
      out.write("\r\n");
      out.write("  <HEAD>\r\n");
      out.write("  <TITLE>会员护理评估统计</TITLE>\r\n");
      out.write("  <script type=\"text/javascript\">\r\n");
      out.write("    var basePath = '");
      out.print(basePath);
      out.write("';\r\n");
      out.write("    var filename= '");
      out.print(filename);
      out.write("' ;\r\n");
      out.write("    window.onunload = function(){\r\n");
      out.write("       //每次离开删除掉服务器上的图片 防止图片太多撑爆服务器磁盘\r\n");
      out.write("       $.ajax({\r\n");
      out.write("\t\t      type : \"POST\",\r\n");
      out.write("\t\t      async:false,\r\n");
      out.write("\t\t      url : basePath + \"/memberdeleteFile.do?filename=\" + filename+\"&r=\"+Math.random(),\r\n");
      out.write("\t\t      success : function(msg) {\r\n");
      out.write("\t\t\t\t\t\tvar result = msg;\r\n");
      out.write("\t\t\t\t\t},\r\n");
      out.write("\t\t\t  failure : function() {\r\n");
      out.write("\t\t\t\t   alert(\"未知错误发生,请联系管理员解决！\");\r\n");
      out.write("\t\t\t  }\r\n");
      out.write("\t   });\r\n");
      out.write("    }\r\n");
      out.write("    function download(filename){\r\n");
      out.write("        $.ajax({\r\n");
      out.write("\t\t\t\t\ttype : \"POST\",\r\n");
      out.write("\t\t\t\t\turl : basePath + \"/download.do?filename=\" + filename,\r\n");
      out.write("\t\t\t\t\tsuccess : function(msg) {\r\n");
      out.write("\t\t\t\t\t\tvar result = msg;\r\n");
      out.write("\t\t\t\t\t\tif ('success' == result) {\r\n");
      out.write("\t\t\t\t\t\t\talert('下载成功');\r\n");
      out.write("\t\t\t\t\t\t\twindow.location.href = basePath + \"/memberlist.do\";\r\n");
      out.write("\t\t\t\t\t\t} else {\r\n");
      out.write("\t\t\t\t\t\t\talert('下载失败');\r\n");
      out.write("\t\t\t\t\t\t}\r\n");
      out.write("\t\t\t\t\t},\r\n");
      out.write("\t\t\t\t\tfailure : function() {\r\n");
      out.write("\t\t\t\t\t\talert(\"未知错误发生,请联系管理员解决！\");\r\n");
      out.write("\t\t\t\t\t}\r\n");
      out.write("\t\t\t\t});\r\n");
      out.write("    }\r\n");
      out.write("  </script>\r\n");
      out.write("  </HEAD>\r\n");
      out.write("\r\n");
      out.write(" <BODY>\r\n");
      out.write("  <P ALIGN=\"CENTER\">\r\n");
      out.write("   <img src=\"");
      out.print(graphURL);
      out.write("\" width=");
      out.print(width);
      out.write(" height=");
      out.print(height);
      out.write(" border=0\r\n");
      out.write("    usemap=\"#");
      out.print( filename );
      out.write("\">\r\n");
      out.write("  </P>\r\n");
      out.write("  <div style=\"text-align:center\">\r\n");
      out.write("\t  <!-- 下载文件链接内容为定义的下载Action -->  \r\n");
      out.write("        <!-- 下载文件名作为链接参数fileName值，用OGNL表达式表达 -->    \r\n");
      out.write("        <a href=\"download.do?filename=");
      out.print(filename );
      out.write("\"><span style=\"color:blue\">[下载至本地]</span></a>\r\n");
      out.write("        <a href=\"memberlist.do\"><span style=\"color:blue\">[返回]</span></a> \r\n");
      out.write("  </div>\r\n");
      out.write(" </BODY>\r\n");
      out.write("</HTML>\r\n");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
