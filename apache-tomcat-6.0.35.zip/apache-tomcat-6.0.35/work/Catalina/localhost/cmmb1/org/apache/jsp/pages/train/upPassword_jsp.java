package org.apache.jsp.pages.train;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import java.util.*;
import com.wootion.idp.view.vo.FordNagativation;

public final class upPassword_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();

  private static java.util.List _jspx_dependants;

  static {
    _jspx_dependants = new java.util.ArrayList(1);
    _jspx_dependants.add("/pages/train/import.jsp");
  }

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.AnnotationProcessor _jsp_annotationprocessor;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_annotationprocessor = (org.apache.AnnotationProcessor) getServletConfig().getServletContext().getAttribute(org.apache.AnnotationProcessor.class.getName());
  }

  public void _jspDestroy() {
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      response.setContentType("text/html; charset=UTF-8");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write('\r');
      out.write('\n');
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");

String path = request.getContextPath();
String basePath = request.getScheme()+"://"+request.getServerName()+":"+request.getServerPort()+path;

      out.write("\r\n");
      out.write("<link href=\"");
      out.print(basePath);
      out.write("/pages/train/skins/css/common.css\" rel=\"stylesheet\" type=\"text/css\" />\r\n");
      out.write("<script type=\"text/javascript\" src=\"");
      out.print(basePath);
      out.write("/js/md5.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\" src=\"");
      out.print(basePath);
      out.write("/js/jquery-1.3.2.min.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\" src=\"");
      out.print(basePath);
      out.write("/pages/train/js/check.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\" src=\"");
      out.print(basePath);
      out.write("/js/My97DatePicker/WdatePicker.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\" src=\"");
      out.print(basePath);
      out.write("/pages/train/js/common.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\" src=\"");
      out.print(basePath);
      out.write("/js/communication.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\" src=\"");
      out.print(basePath);
      out.write("/js/validate.js\"></script>\r\n");
      out.write("\r\n");
      out.write("<html>\r\n");
      out.write("<head>\r\n");
      out.write("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">\r\n");
      out.write("<title>修改密码</title>\r\n");
      out.write("<script type=\"text/javascript\">\r\n");
      out.write("function onSubmit(){\r\n");
      out.write("\tvar obj = document.forms[0];\r\n");
      out.write("\t\r\n");
      out.write("\tif(check(\"oldpassword2\",\"string\",\"旧密码不能为空！\"))return false;\r\n");
      out.write("\t\r\n");
      out.write("\tif(hex_md5(obj.oldpassword2.value) != obj.oldpassword.value){\r\n");
      out.write("\t\tdocument.getElementById(\"ERROR_MSG\").innerHTML = \"旧密码不正确！\";\r\n");
      out.write("\t\tobj.oldpassword2.className = \"errorInput\";\r\n");
      out.write("\t\tobj.oldpassword2.focus();\r\n");
      out.write("\t\treturn false;\r\n");
      out.write("\t}else{\r\n");
      out.write("\t\tdocument.getElementById(\"ERROR_MSG\").innerHTML = \"\";\r\n");
      out.write("\t\tobj.oldpassword2.className = \"\";\r\n");
      out.write("\t}\r\n");
      out.write("\r\n");
      out.write("\tif(check(\"password\",\"string\",\"密码不能为空！\") ||\r\n");
      out.write("\t\tcheck(\"password2\",\"string\",\"请在次确认密码！\"))return false;\r\n");
      out.write("\t\r\n");
      out.write("\tif(obj.password.value != obj.password2.value){\r\n");
      out.write("\t\tdocument.getElementById(\"ERROR_MSG\").innerHTML = \"两次密码输入不一致！\";\r\n");
      out.write("\t\tobj.password.className = \"errorInput\";\r\n");
      out.write("\t\tobj.password2.className = \"errorInput\";\r\n");
      out.write("\t\tobj.password.focus();\r\n");
      out.write("\t\treturn false;\r\n");
      out.write("\t}else{\r\n");
      out.write("\t\tdocument.getElementById(\"ERROR_MSG\").innerHTML = \"\";\r\n");
      out.write("\t\tobj.password.className = \"\";\r\n");
      out.write("\t\tobj.password2.className = \"\";\r\n");
      out.write("\t}\r\n");
      out.write("\t\r\n");
      out.write("\tif(hex_md5(obj.password.value) == obj.oldpassword.value){\r\n");
      out.write("\t\tdocument.getElementById(\"ERROR_MSG\").innerHTML = \"旧密码与新密码相同！\";\r\n");
      out.write("\t\tobj.oldpassword2.className = \"errorInput\";\r\n");
      out.write("\t\tobj.password.className = \"errorInput\";\r\n");
      out.write("\t\tobj.password2.className = \"errorInput\";\r\n");
      out.write("\t\tobj.password.focus();\r\n");
      out.write("\t\treturn false;\r\n");
      out.write("\t}else{\r\n");
      out.write("\t\tdocument.getElementById(\"ERROR_MSG\").innerHTML = \"\";\r\n");
      out.write("\t\tobj.oldpassword2.className = \"\";\r\n");
      out.write("\t\tobj.password.className = \"\";\r\n");
      out.write("\t\tobj.password2.className = \"\";\r\n");
      out.write("\t}\r\n");
      out.write("\t\r\n");
      out.write("\tobj.password.value = hex_md5(obj.password.value);\r\n");
      out.write("}\r\n");
      out.write("</script>\r\n");
      out.write("</head>\r\n");
      out.write("<body>\r\n");
      out.write("<div class=\"topLanBar\"><b>当前位置：</b>修改密码</div>\r\n");
      out.write("<table width=\"100%\">\r\n");
      out.write("  <tr>\r\n");
      out.write("    <td background=\"");
      out.print(basePath);
      out.write("/pages/train/skins/img/lan-index.gif\">&nbsp;</td>\r\n");
      out.write("  </tr>\r\n");
      out.write("</table>\r\n");
      out.write("<form method=\"post\" action=\"uppassworddo.do\" onSubmit=\"return onSubmit()\">\r\n");
      out.write("<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"5\">\r\n");
      out.write("  \r\n");
      out.write("    <input type=\"hidden\" name=\"userID\" value=\"");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${user.wtuserId}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
      out.write("\">\r\n");
      out.write("\t\t<input type=\"hidden\" name=\"oldpassword\" value=\"");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${user.wtuserPassword}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
      out.write("\">\r\n");
      out.write("    <tr>\r\n");
      out.write("      <td align=\"right\">账号</td>\r\n");
      out.write("      <td>");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${user.wtuserLoginname}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
      out.write("</td>\r\n");
      out.write("    </tr>\r\n");
      out.write("    <tr>\r\n");
      out.write("      <td align=\"right\">旧密码</td>\r\n");
      out.write("      <td><input type=\"password\" name=\"oldpassword2\"></td>\r\n");
      out.write("    </tr>\r\n");
      out.write("    <tr>\r\n");
      out.write("      <td align=\"right\">新密码</td>\r\n");
      out.write("      <td><input type=\"password\" name=\"password\"></td>\r\n");
      out.write("    </tr>\r\n");
      out.write("    <tr>\r\n");
      out.write("      <td align=\"right\">再次确认</td>\r\n");
      out.write("      <td><input type=\"password\" name=\"password2\"></td>\r\n");
      out.write("    </tr>\r\n");
      out.write("    <tr>\r\n");
      out.write("      <td align=\"right\">&nbsp;</td>\r\n");
      out.write("      <td id=\"ERROR_MSG\"></td>\r\n");
      out.write("    </tr>\r\n");
      out.write("    <tr>\r\n");
      out.write("      <td>&nbsp;</td>\r\n");
      out.write("      <td><button type=\"submit\">修改</button></td>\r\n");
      out.write("    </tr>\r\n");
      out.write("  \r\n");
      out.write("</table>\r\n");
      out.write("</form>\r\n");
      out.write("</body>\r\n");
      out.write("</html>\r\n");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
