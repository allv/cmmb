package org.apache.jsp.pages.train.user;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;

public final class add_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();

  private static java.util.List _jspx_dependants;

  static {
    _jspx_dependants = new java.util.ArrayList(1);
    _jspx_dependants.add("/pages/train/user/../import.jsp");
  }

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.AnnotationProcessor _jsp_annotationprocessor;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_annotationprocessor = (org.apache.AnnotationProcessor) getServletConfig().getServletContext().getAttribute(org.apache.AnnotationProcessor.class.getName());
  }

  public void _jspDestroy() {
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      response.setContentType("text/html; charset=UTF-8");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write('\r');
      out.write('\n');
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");

String path = request.getContextPath();
String basePath = request.getScheme()+"://"+request.getServerName()+":"+request.getServerPort()+path;

      out.write("\r\n");
      out.write("<link href=\"");
      out.print(basePath);
      out.write("/pages/train/skins/css/common.css\" rel=\"stylesheet\" type=\"text/css\" />\r\n");
      out.write("<script type=\"text/javascript\" src=\"");
      out.print(basePath);
      out.write("/js/md5.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\" src=\"");
      out.print(basePath);
      out.write("/js/jquery-1.3.2.min.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\" src=\"");
      out.print(basePath);
      out.write("/pages/train/js/check.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\" src=\"");
      out.print(basePath);
      out.write("/pages/train/js/LodopFuncs.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\" src=\"");
      out.print(basePath);
      out.write("/js/My97DatePicker/WdatePicker.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\" src=\"");
      out.print(basePath);
      out.write("/pages/train/js/common.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\" src=\"");
      out.print(basePath);
      out.write("/js/communication.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\" src=\"");
      out.print(basePath);
      out.write("/js/validate.js\"></script>\r\n");
      out.write("\r\n");
      out.write("<html>\r\n");
      out.write("<head>\r\n");
      out.write("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">\r\n");
      out.write("<title>注册用户</title>\r\n");
      out.write("<script type=\"text/javascript\">\r\n");
      out.write("function onSubmit(){\r\n");
      out.write("\tif(check(\"username\",\"string\",\"账号不能为空！\") ||\r\n");
      out.write("\t\tcheck(\"password\",\"string\",\"密码不能为空！\") ||\r\n");
      out.write("\t\tcheck(\"password2\",\"string\",\"请在次确认密码！\")\r\n");
      out.write("\t\t)return false;\r\n");
      out.write("    \r\n");
      out.write("\tvar obj = document.forms[0];\r\n");
      out.write("\tif(obj.password.value != obj.password2.value){\r\n");
      out.write("\t\tdocument.getElementById(\"ERROR_MSG\").innerHTML = \"两次密码输入不一致！\";\r\n");
      out.write("\t\tobj.password.className = \"errorInput\";\r\n");
      out.write("\t\tobj.password2.className = \"errorInput\";\r\n");
      out.write("\t\tobj.password.focus();\r\n");
      out.write("\t\treturn false;\r\n");
      out.write("\t}\r\n");
      out.write("\tif(check(\"corpName\",\"string\",\"姓名不能为空！\")){\r\n");
      out.write("        return false;\r\n");
      out.write("    }\r\n");
      out.write("\tobj.password.value = hex_md5(obj.password.value);\r\n");
      out.write("\t//obj.password2.value = hex_md5(obj.password2.value);\r\n");
      out.write("\tvar typeobj = document.getElementsByName(\"type\");\r\n");
      out.write("\tvar type;\r\n");
      out.write("    for(i=0;i<typeobj.length;i++){\r\n");
      out.write("\t\t  if(typeobj[i].checked==true){\r\n");
      out.write("\t\t    type = typeobj[i].value;\r\n");
      out.write("\t\t}\r\n");
      out.write("\t}\r\n");
      out.write("}\r\n");
      out.write("</script>\r\n");
      out.write("</head>\r\n");
      out.write("<body>\r\n");
      out.write("<div class=\"topLanBar\"><b>当前位置：</b>帐号管理 > 新增帐号</div>\r\n");
      out.write("<table width=\"100%\">\r\n");
      out.write("  <tr>\r\n");
      out.write("    <td background=\"");
      out.print(basePath);
      out.write("/pages/train/skins/img/lan-index.gif\">&nbsp;</td>\r\n");
      out.write("  </tr>\r\n");
      out.write("</table>\r\n");
      out.write("<form  method=\"post\" action=\"adduser.do\" onSubmit=\"return onSubmit()\">\r\n");
      out.write("<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"5\">\r\n");
      out.write("\r\n");
      out.write("  <tr>\r\n");
      out.write("      <td colspan=\"2\" bgcolor=\"#66DD00\"><b>快速注册</b></td>\r\n");
      out.write("    </tr>\r\n");
      out.write("    <tr>\r\n");
      out.write("      <td align=\"right\">账号</td>\r\n");
      out.write("      <td><input type=\"text\" name=\"username\" value=\"");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${username}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
      out.write("\"><span style='color:red;'>&nbsp;*</span></td>\r\n");
      out.write("    </tr>\r\n");
      out.write("    <tr>\r\n");
      out.write("      <td align=\"right\">密码</td>\r\n");
      out.write("      <td><input type=\"password\" name=\"password\"><span style='color:red;'>&nbsp;*</span></td>\r\n");
      out.write("    </tr>\r\n");
      out.write("    <tr>\r\n");
      out.write("      <td align=\"right\">确认密码</td>\r\n");
      out.write("      <td><input type=\"password\" name=\"password2\"><span style='color:red;'>&nbsp;*</span></td>\r\n");
      out.write("    </tr>\r\n");
      out.write("    \r\n");
      out.write("    <!-- \r\n");
      out.write("    <tr>\r\n");
      out.write("        <td align=\"right\">帐号类型</td>\r\n");
      out.write("\t    <td nowrap class=\"TableData\" colspan=\"3\">\r\n");
      out.write("\t    \t<input type=\"radio\" name=\"type\" id=\"type\" value=\"x\" checked=\"checked\" /> 行政人员&nbsp;&nbsp;\r\n");
      out.write("\t\t\t<input type=\"radio\" name=\"type\" id=\"type\" value=\"h\" /> 医生&nbsp;&nbsp;\r\n");
      out.write("\t\t\t<input type=\"radio\" name=\"type\" id=\"type\" value=\"k\" /> 康复人员\r\n");
      out.write("\t    </td>\r\n");
      out.write("    </tr>\r\n");
      out.write("     -->\r\n");
      out.write("    <tr>\r\n");
      out.write("      <td colspan=\"2\" bgcolor=\"#66DD00\"><b>人员详情</b></td>\r\n");
      out.write("    </tr>\r\n");
      out.write("    <tr>\r\n");
      out.write("      <td align=\"right\">姓名</td>\r\n");
      out.write("      <td><input name=\"corpName\" type=\"text\" value=\"");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${corpName}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
      out.write("\" size=\"20\"><span style='color:red;'>&nbsp;*</span></td>\r\n");
      out.write("    </tr>\r\n");
      out.write("    \r\n");
      out.write("    <tr>\r\n");
      out.write("      <td align=\"right\">性别</td>\r\n");
      out.write("      <td>\r\n");
      out.write("         <input id=\"corpAP\" name=\"corpAP\" type=\"radio\" class=\"radio\"  value=\"1\" checked><label name=\"corpAP\" class=\"checked\" for=\"corpAP\">男 &nbsp;&nbsp;&nbsp;</label>\r\n");
      out.write("         <input id=\"corpAP1\" name=\"corpAP\" type=\"radio\" class=\"radio\"  value=\"2\"><label name=\"corpAP1\" for=\"corpAP1\">女</label>\r\n");
      out.write("      </td>\r\n");
      out.write("    </tr>\r\n");
      out.write("    \r\n");
      out.write("    <tr>\r\n");
      out.write("      <td align=\"right\">联系电话</td>\r\n");
      out.write("       <td>\r\n");
      out.write("      <input name=\"linkmanTel\" type=\"text\" value=\"");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${linkmanTel}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
      out.write("\"></td>\r\n");
      out.write("    </tr>\r\n");
      out.write("    \r\n");
      out.write("    <tr>\r\n");
      out.write("      <td align=\"right\">住址</td>\r\n");
      out.write("      <td><input name=\"corpAdd\" type=\"text\" value=\"");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${corpAdd}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
      out.write("\" size=\"56\"></td>\r\n");
      out.write("    </tr>\r\n");
      out.write("    \r\n");
      out.write("    <tr>\r\n");
      out.write("      <td align=\"right\">E-mail</td>\r\n");
      out.write("      <td><input name=\"linkmanEmail\" type=\"text\" value=\"");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${linkmanEmail}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
      out.write("\" size=\"56\"></td>\r\n");
      out.write("    </tr>\r\n");
      out.write("   \r\n");
      out.write("    <tr>\r\n");
      out.write("      <td align=\"right\">工作职责简介</td>\r\n");
      out.write("      <td><textarea name=\"corpNote\" cols=\"58\" rows=\"4\">");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${corpNote}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
      out.write("</textarea></td>\r\n");
      out.write("    </tr>\r\n");
      out.write("  <tr>\r\n");
      out.write("    <td align=\"right\">&nbsp;</td>\r\n");
      out.write("    <td id=\"ERROR_MSG\">");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${msg}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
      out.write("</td>\r\n");
      out.write("  </tr>\r\n");
      out.write("  <tr>\r\n");
      out.write("    <td>&nbsp;</td>\r\n");
      out.write("    <td><button type=\"submit\">提交</button> \r\n");
      out.write("\t\t<button onClick=\"forward('queryuser.do')\">返回</button></td>\r\n");
      out.write("  </tr>\r\n");
      out.write("\r\n");
      out.write("</table>\r\n");
      out.write("</form>\r\n");
      out.write("<script type=\"text/javascript\">\r\n");
      out.write("var labels=document.getElementsByTagName('label');\r\n");
      out.write("var radios=document.getElementsByName('corpAP');\r\n");
      out.write("function initClass(labesindex,labeindex){\r\n");
      out.write("   for(i=labesindex,j=labeindex ; i<j ; i++)\r\n");
      out.write("   {\r\n");
      out.write("       labels[i].onclick=function() \r\n");
      out.write("       {\r\n");
      out.write("\t\t    if(this.className == '') {\r\n");
      out.write("\t\t       for(k=labesindex,l=labeindex ; k<l ; k++)\r\n");
      out.write("\t\t       {\r\n");
      out.write("\t\t          labels[k].className='';\r\n");
      out.write("\t\t     \t  radios[k].checked = false;\r\n");
      out.write("\t\t       }\r\n");
      out.write("\t\t       this.className='checked';\r\n");
      out.write("\t\t       try{\r\n");
      out.write("\t\t    \t   document.getElementById(this.name).checked = true;\r\n");
      out.write("\t\t       }catch (e) {}\r\n");
      out.write("\t\t    }\r\n");
      out.write("       }\r\n");
      out.write("   }\r\n");
      out.write("   labels[labesindex].click();\r\n");
      out.write("}\r\n");
      out.write("\r\n");
      out.write("initClass(0,2);\r\n");
      out.write("</script>\r\n");
      out.write("</body>\r\n");
      out.write("</html>\r\n");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
