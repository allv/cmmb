package org.apache.jsp.pages.train;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;

public final class login_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();

  private static java.util.List _jspx_dependants;

  static {
    _jspx_dependants = new java.util.ArrayList(1);
    _jspx_dependants.add("/pages/train/import.jsp");
  }

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.AnnotationProcessor _jsp_annotationprocessor;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_annotationprocessor = (org.apache.AnnotationProcessor) getServletConfig().getServletContext().getAttribute(org.apache.AnnotationProcessor.class.getName());
  }

  public void _jspDestroy() {
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      response.setContentType("text/html;charset=utf-8");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write('\r');
      out.write('\n');
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");

String path = request.getContextPath();
String basePath = request.getScheme()+"://"+request.getServerName()+":"+request.getServerPort()+path;

      out.write("\r\n");
      out.write("<link href=\"");
      out.print(basePath);
      out.write("/pages/train/skins/css/common.css\" rel=\"stylesheet\" type=\"text/css\" />\r\n");
      out.write("<script type=\"text/javascript\" src=\"");
      out.print(basePath);
      out.write("/js/md5.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\" src=\"");
      out.print(basePath);
      out.write("/js/jquery-1.3.2.min.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\" src=\"");
      out.print(basePath);
      out.write("/pages/train/js/check.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\" src=\"");
      out.print(basePath);
      out.write("/pages/train/js/LodopFuncs.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\" src=\"");
      out.print(basePath);
      out.write("/js/My97DatePicker/WdatePicker.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\" src=\"");
      out.print(basePath);
      out.write("/pages/train/js/common.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\" src=\"");
      out.print(basePath);
      out.write("/js/communication.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\" src=\"");
      out.print(basePath);
      out.write("/js/validate.js\"></script>\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("<html>\r\n");
      out.write("<head>\r\n");
      out.write("<meta http-equiv=\"pragma\" content=\"no-cache\">\r\n");
      out.write("<meta http-equiv=\"cache-control\" content=\"no-cache\">\r\n");
      out.write("<meta http-equiv=\"expires\" content=\"0\">\r\n");
      out.write("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />\r\n");
      out.write("<title>HBJJ伙伴聚家办公平台 - 登录</title>\r\n");
      out.write("<style type=\"text/css\">\r\n");
      out.write("<!--\r\n");
      out.write("BODY {\r\n");
      out.write("\tmargin: 0px;\r\n");
      out.write("\tbackground-color: #66CC66;\r\n");
      out.write("\toverflow: hidden;\r\n");
      out.write("\tbackground-image: url(");
      out.print(basePath);
      out.write("/pages/train/skins/img/loginback.jpg);\r\n");
      out.write("\tbackground-repeat: repeat-x;\r\n");
      out.write("}\r\n");
      out.write("#login_layout {\r\n");
      out.write("\theight: 100%;\r\n");
      out.write("\twidth: 100%;\r\n");
      out.write("\ttext-align:center;\r\n");
      out.write("\tmargin-left:auto;\r\n");
      out.write("\tmargin-right:auto;\r\n");
      out.write("\tpadding-top: 8%;\r\n");
      out.write("}\r\n");
      out.write("#login_layout #LOGO {\r\n");
      out.write("\twidth: 37%;\r\n");
      out.write("\tmargin-left:auto;\r\n");
      out.write("\tmargin-right:auto;\r\n");
      out.write("}\r\n");
      out.write("#login_layout #LOGO #font_CN {\r\n");
      out.write("\tfont-family: \"黑体\";\r\n");
      out.write("\tfont-size: 26px;\r\n");
      out.write("\tfont-weight: bold;\r\n");
      out.write("\tcolor: #FFFFFF;\r\n");
      out.write("\tfilter: DropShadow(Color = #cccccc, OffX = 1, OffY = 1, Positive = 20);\r\n");
      out.write("}\r\n");
      out.write("#login_layout #LOGO #font_EN {\r\n");
      out.write("\tfont-family: Verdana, Arial, Helvetica, sans-serif;\r\n");
      out.write("\tcolor: #E0E0E0;\r\n");
      out.write("\tfont-size: 14px;\r\n");
      out.write("\tfont-weight: bold;\r\n");
      out.write("\tmargin-left:auto;\r\n");
      out.write("\tmargin-right:auto;\r\n");
      out.write("\tfilter: DropShadow(Color = #cccccc, OffX = 1, OffY = 1, Positive = 20);\r\n");
      out.write("}\r\n");
      out.write("#login_layout #login_DIV {\r\n");
      out.write("\tbackground-color: #99CC99;\r\n");
      out.write("\theight: 30%;\r\n");
      out.write("\twidth: 37%;\r\n");
      out.write("\ttext-align:center;\r\n");
      out.write("\tmargin-left:auto;\r\n");
      out.write("\tmargin-right:auto;\r\n");
      out.write("\tborder: 4px solid #66CC00;\r\n");
      out.write("\tpadding: 40px;\r\n");
      out.write("}\r\n");
      out.write("#login_layout #login_DIV td {\r\n");
      out.write("\tcolor: #DBDBDB;\r\n");
      out.write("\tfont-weight: bold;\r\n");
      out.write("}\r\n");
      out.write("#login_layout #login_DIV input {\r\n");
      out.write("\tfont-family: Verdana, Arial, Helvetica, sans-serif;\r\n");
      out.write("\theight: 24px;\r\n");
      out.write("\tborder: 1px solid #CCCCCC;\r\n");
      out.write("\tline-height: 24px;\r\n");
      out.write("\tfont-size: 14px;\r\n");
      out.write("\tfont-weight: bold;\r\n");
      out.write("\tcolor: #666666;\r\n");
      out.write("}\r\n");
      out.write("#login_layout #login_DIV button {\r\n");
      out.write("\theight: 22px;\r\n");
      out.write("\twidth: 100px;\r\n");
      out.write("\tborder-top-width: 0px;\r\n");
      out.write("\tborder-right-width: 0px;\r\n");
      out.write("\tborder-bottom-width: 0px;\r\n");
      out.write("\tborder-left-width: 0px;\r\n");
      out.write("\tcursor: hand;\r\n");
      out.write("\tbackground-image: none;\r\n");
      out.write("}\r\n");
      out.write("#login_layout #login_DIV a {\r\n");
      out.write("\tcolor: #CBD7ED;\r\n");
      out.write("\ttext-decoration: underline;\r\n");
      out.write("}\r\n");
      out.write("-->\r\n");
      out.write("</style>\r\n");
      out.write("<script type=\"text/javascript\">\r\n");
      out.write("window.onload = function(){\r\n");
      out.write("\tif(top != window)\r\n");
      out.write("\t\ttop.location.href = \"");
      out.print(basePath);
      out.write("\";\r\n");
      out.write("\t\t\r\n");
      out.write("}\r\n");
      out.write("\r\n");
      out.write("function onSubmit(){\r\n");
      out.write("\tif(check(\"username\",\"string\",\"用户名不能为空！\") ||\r\n");
      out.write("\t\tcheck(\"password\",\"string\",\"密码不能为空！\"))return false;\r\n");
      out.write("\t\t\r\n");
      out.write("\t$(\"#password\").val(hex_md5($(\"#password\").val()));\r\n");
      out.write("}\r\n");
      out.write("function shownew(){\r\n");
      out.write("\t$(\"#spic\").attr(\"src\", function() {\r\n");
      out.write("\t\t$(\"#spic\").removeAttr(\"src\"); \r\n");
      out.write("\t\treturn \"");
      out.print(basePath);
      out.write("/pages/train/random.jsp\";\r\n");
      out.write("\t}); \r\n");
      out.write("}\r\n");
      out.write("</script>\r\n");
      out.write("</head>\r\n");
      out.write("<body>\r\n");
      out.write("<div id=\"login_layout\">\r\n");
      out.write("<div id=\"LOGO\">\r\n");
      out.write("<table width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">\r\n");
      out.write("  <tr>\r\n");
      out.write("    <td align=\"center\" id=\"font_CN\">HBJJ伙伴聚家办公平台</td>\r\n");
      out.write("  </tr>\r\n");
      out.write("  <tr>\r\n");
      out.write("    <td align=\"center\" id=\"font_EN\">HBJJ Office Management Platform</td>\r\n");
      out.write("  </tr>\r\n");
      out.write("</table>\r\n");
      out.write("</div><br>\r\n");
      out.write("<div id=\"login_DIV\">\r\n");
      out.write("<form action=\"");
      out.print(basePath);
      out.write("/login.do\" method=\"post\" onSubmit=\"return onSubmit()\">\r\n");
      out.write("  <table width=\"100%\" cellpadding=\"8\">\r\n");
      out.write("    <tr>\r\n");
      out.write("      <td align=\"right\"><span style=\"color:black\">用户名</span></td>\r\n");
      out.write("      <td><input id=\"username\" name=\"username\" type=\"text\" value=\"admin\"></td>\r\n");
      out.write("    </tr>\r\n");
      out.write("    <tr>\r\n");
      out.write("      <td align=\"right\"><span style=\"color:black\">密码</span></td>\r\n");
      out.write("      <td><input id=\"password\" name=\"password\" type=\"password\" value=\"admin\"></td>\r\n");
      out.write("    </tr>\r\n");
      out.write("    \r\n");
      out.write("    <tr>\r\n");
      out.write("      <td>&nbsp;</td>\r\n");
      out.write("      <td><span id=\"ERROR_MSG\">");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${msg }", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
      out.write("</span></td>\r\n");
      out.write("    </tr>\r\n");
      out.write("    <tr>\r\n");
      out.write("      <td width=\"120\">&nbsp;</td>\r\n");
      out.write("      <td align=\"right\">\r\n");
      out.write("\t\t\t<!-- <a href=\"userregister.do\">注册</a> ｜ -->\r\n");
      out.write("\t\t\t<button type=\"submit\">\r\n");
      out.write("\t\t\t<img src=\"");
      out.print(basePath);
      out.write("/pages/train/skins/img/logbutton.png\">\r\n");
      out.write("\t\t\t</button></td>\r\n");
      out.write("    </tr>\r\n");
      out.write("\t\r\n");
      out.write("  </table>\r\n");
      out.write("  </form>\r\n");
      out.write("</div>\r\n");
      out.write("<div style=\"width:37%;margin-left:auto;margin-right:auto;\">&copy; 2012-2013 HBJJ Corporation, All Rights Reserved.</div>\r\n");
      out.write("</div>\r\n");
      out.write("</body>\r\n");
      out.write("</html>\r\n");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
