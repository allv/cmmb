package org.apache.jsp.pages.train.cseries;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import java.util.*;
import com.wootion.idp.view.vo.FordNagativation;

public final class proview_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();

  private static java.util.List _jspx_dependants;

  static {
    _jspx_dependants = new java.util.ArrayList(1);
    _jspx_dependants.add("/pages/train/cseries/../import.jsp");
  }

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.AnnotationProcessor _jsp_annotationprocessor;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_annotationprocessor = (org.apache.AnnotationProcessor) getServletConfig().getServletContext().getAttribute(org.apache.AnnotationProcessor.class.getName());
  }

  public void _jspDestroy() {
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      response.setContentType("text/html; charset=UTF-8");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write('\r');
      out.write('\n');
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");

String path = request.getContextPath();
String basePath = request.getScheme()+"://"+request.getServerName()+":"+request.getServerPort()+path;

      out.write("\r\n");
      out.write("<link href=\"");
      out.print(basePath);
      out.write("/pages/train/skins/css/common.css\" rel=\"stylesheet\" type=\"text/css\" />\r\n");
      out.write("<script type=\"text/javascript\" src=\"");
      out.print(basePath);
      out.write("/js/md5.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\" src=\"");
      out.print(basePath);
      out.write("/js/jquery-1.3.2.min.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\" src=\"");
      out.print(basePath);
      out.write("/pages/train/js/check.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\" src=\"");
      out.print(basePath);
      out.write("/js/My97DatePicker/WdatePicker.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\" src=\"");
      out.print(basePath);
      out.write("/pages/train/js/common.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\" src=\"");
      out.print(basePath);
      out.write("/js/communication.js\"></script>\r\n");
      out.write("\r\n");
      out.write("<html>\r\n");
      out.write("<head>\r\n");
      out.write("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">\r\n");
      out.write("<title>项目详细</title>\r\n");
      out.write("<script type=\"text/javascript\">\r\n");
      out.write("var basePath = '");
      out.print(basePath);
      out.write("';\r\n");
      out.write("</script>\r\n");
      out.write("</head>\r\n");
      out.write("<body>\r\n");
      out.write("<div class=\"topLanBar\"><b>当前位置：</b>项目管理 > 项目详情</div>\r\n");
      out.write("<table width=\"100%\">\r\n");
      out.write("  <tr>\r\n");
      out.write("    <td background=\"");
      out.print(basePath);
      out.write("/pages/train/skins/img/lan-index.gif\">&nbsp;</td>\r\n");
      out.write("  </tr>\r\n");
      out.write("</table>\r\n");
      out.write("<form  method=\"post\">\r\n");
      out.write("<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"5\">\r\n");
      out.write("    <tr>\r\n");
      out.write("      <td colspan=\"5\" bgcolor=\"#CBD7ED\"><b>项目信息</b></td>\r\n");
      out.write("    </tr>\r\n");
      out.write("    <tr>\r\n");
      out.write("      <td align=\"left\">项目编号：<input type=\"text\" name=\"proidentity\" value=\"");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${pro.proidentity}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
      out.write("\" disabled></td>\r\n");
      out.write("      <td align=\"justify\">项目名称：<input type=\"text\" name=\"proname\" value=\"");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${pro.proname}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
      out.write("\" disabled></td>\r\n");
      out.write("      <td align=\"justify\">项目状态：<input type=\"text\" name=\"prostate\" value=\"");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${pro.prostate}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
      out.write("\" disabled></td>\r\n");
      out.write("    </tr>\r\n");
      out.write("    <tr>\r\n");
      out.write("      <td align=\"left\">总负责人：<input type=\"text\" name=\"proresponsor\" value=\"");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${pro.proresponsor}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
      out.write("\" disabled></td>\r\n");
      out.write("      <td align=\"justify\">招标单位：<input type=\"text\" name=\"proagency\" value=\"");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${pro.proagency}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
      out.write("\" disabled></td>\r\n");
      out.write("      <td align=\"justify\">项目权限：<input type=\"text\" name=\"proauthority\" value=\"");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${pro.proauthority}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
      out.write("\" disabled></td>\r\n");
      out.write("    </tr>\r\n");
      out.write("    <tr>\r\n");
      out.write("      <td align=\"left\">招标结果：<input type=\"text\" name=\"proresult\" value=\"");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${pro.proresult}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
      out.write("\" disabled></td>\r\n");
      out.write("      <td align=\"justify\">合同编号：<input type=\"text\" name=\"procontract\" value=\"");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${pro.procontract}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
      out.write("\" disabled></td>\r\n");
      out.write("      <td align=\"justify\">开始日期：<input value=\"");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${pro.prostartdate}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
      out.write("\" disabled type=\"text\" size=\"20\" name=\"prostartdate\"/></td>\r\n");
      out.write("    </tr>\r\n");
      out.write("    \r\n");
      out.write("    <tr>\r\n");
      out.write("      <td align=\"left\">项目金额：<input type=\"text\" name=\"probudget\" value=\"");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${pro.probudget}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
      out.write("\" disabled></td>\r\n");
      out.write("      <td align=\"justify\">拨款次数：<input type=\"text\" name=\"protimes\" value=\"");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${pro.protimes}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
      out.write("\" disabled></td>\r\n");
      out.write("      <td align=\"justify\">结束日期：<input value=\"");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${pro.proenddate}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
      out.write("\" disabled type=\"text\" size=\"20\" name=\"proenddate\" /></td>\r\n");
      out.write("    </tr>\r\n");
      out.write("    <tr>\r\n");
      out.write("      <td align=\"justify\" colspan=\"5\">项目简介：\r\n");
      out.write("         <textarea rows=\"4\" cols=\"90\" name=\"prodesc\" disabled>");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${pro.prodesc}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
      out.write("</textarea>\r\n");
      out.write("      </td>\r\n");
      out.write("    </tr>\r\n");
      out.write("    \r\n");
      out.write("    <tr>\r\n");
      out.write("      \t <td colspan=\"5\" bgcolor=\"#CBD7ED\"><b>护理评估</b></td>\r\n");
      out.write("      \t <td colspan=\"4\" align=\"right\"></td>\r\n");
      out.write("    </tr>\r\n");
      out.write("    <tbody id=\"01\">\r\n");
      out.write("    <tr>\r\n");
      out.write("        <td align=\"left\">每月计划评估人次：<input type=\"text\" name=\"peopletime\" value=\"");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${pro.hlpgtime}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
      out.write("\" disabled></td>\r\n");
      out.write("      \t\r\n");
      out.write("      \t<td align=\"left\">指定负责人：<input type=\"text\" id=\"chargeman\" name=\"chargeman\" value=\"");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${pro.hlpgman}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
      out.write("\" disabled></td>\r\n");
      out.write("    </tr>\r\n");
      out.write("    </tbody>\r\n");
      out.write("\r\n");
      out.write("    <tr>\r\n");
      out.write("      \t <td colspan=\"5\" bgcolor=\"#CBD7ED\"><b>康复评估</b></td>\r\n");
      out.write("      \t <td colspan=\"4\" align=\"right\"></td>\r\n");
      out.write("    </tr>\r\n");
      out.write("    <tbody id=\"02\">\r\n");
      out.write("    <tr>\r\n");
      out.write("        <td align=\"left\">每月计划评估人次：<input type=\"text\" name=\"peopletime1\" value=\"");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${pro.kfpgtime}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
      out.write("\" disabled></td>\r\n");
      out.write("      \t\r\n");
      out.write("      \t<td align=\"left\">指定负责人：<input type=\"text\" id=\"chargeman1\" name=\"chargeman1\" value=\"");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${pro.kfpgman}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
      out.write("\" disabled></td>\r\n");
      out.write("    </tr>\r\n");
      out.write("    </tbody>\r\n");
      out.write("\r\n");
      out.write("    <tr>\r\n");
      out.write("      \t <td colspan=\"5\" bgcolor=\"#CBD7ED\"><b>护理服务</b></td>\r\n");
      out.write("      \t <td colspan=\"4\" align=\"right\"></td>\r\n");
      out.write("    </tr>\r\n");
      out.write("    <tbody id=\"03\">\r\n");
      out.write("    <tr>\r\n");
      out.write("        <td align=\"left\">每月计划评估人次：<input type=\"text\" name=\"peopletime2\" value=\"");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${pro.hlfwtime}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
      out.write("\" disabled></td>\r\n");
      out.write("      \t<td align=\"left\">指定负责人：<input type=\"text\" id=\"chargeman2\" name=\"chargeman2\" value=\"");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${pro.hlfwman}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
      out.write("\" disabled></td>\r\n");
      out.write("    </tr>\r\n");
      out.write("    </tbody>\r\n");
      out.write("    \r\n");
      out.write("    <tr>\r\n");
      out.write("      \t <td colspan=\"5\" bgcolor=\"#CBD7ED\"><b>康复服务</b></td>\r\n");
      out.write("      \t <td colspan=\"4\" align=\"right\"></td>\r\n");
      out.write("    </tr>\r\n");
      out.write("    <tbody id=\"04\">\r\n");
      out.write("    <tr>\r\n");
      out.write("        <td align=\"left\">每月计划评估人次：<input type=\"text\" name=\"peopletime3\" value=\"");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${pro.kffwtime}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
      out.write("\" disabled></td>\r\n");
      out.write("      \t\r\n");
      out.write("      \t<td align=\"left\">指定负责人：<input type=\"text\" id=\"chargeman3\" name=\"chargeman3\" value=\"");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${pro.kffwman}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
      out.write("\" disabled></td>\r\n");
      out.write("    </tr>\r\n");
      out.write("    </tbody>\r\n");
      out.write("    \r\n");
      out.write("    <tr>\r\n");
      out.write("      \t <td colspan=\"5\" bgcolor=\"#CBD7ED\"><b>培训</b></td>\r\n");
      out.write("      \t <td colspan=\"4\" align=\"right\"></td>\r\n");
      out.write("    </tr>\r\n");
      out.write("    <tbody id=\"05\">\r\n");
      out.write("    <tr>\r\n");
      out.write("        <td align=\"left\">每月计划评估人次：<input type=\"text\" name=\"peopletime4\" value=\"");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${pro.pxtime}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
      out.write("\" disabled></td>\r\n");
      out.write("      \t<td align=\"left\">指定负责人：<input type=\"text\" id=\"chargeman4\" name=\"chargeman4\" value=\"");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${pro.pxman}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
      out.write("\" disabled></td>\r\n");
      out.write("    </tr>\r\n");
      out.write("    </tbody>\r\n");
      out.write("    \r\n");
      out.write("    \r\n");
      out.write("    <tr>\r\n");
      out.write("      \t <td colspan=\"5\" bgcolor=\"#CBD7ED\"><b>活动</b></td>\r\n");
      out.write("      \t <td colspan=\"4\" align=\"right\"></td>\r\n");
      out.write("    </tr>\r\n");
      out.write("    <tbody id=\"06\">\r\n");
      out.write("    <tr>\r\n");
      out.write("        <td align=\"left\">每月计划评估人次：<input type=\"text\" name=\"peopletime5\" value=\"");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${pro.acttime}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
      out.write("\" disabled></td>\r\n");
      out.write("      \t<td align=\"left\">指定负责人：<input type=\"text\" id=\"chargeman5\" name=\"chargeman5\" value=\"");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${pro.actman}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
      out.write("\" disabled></td>\r\n");
      out.write("    </tr>\r\n");
      out.write("    </tbody>\r\n");
      out.write("\r\n");
      out.write("    <tr>\r\n");
      out.write("    <td align=\"right\">&nbsp;</td>\r\n");
      out.write("    <td id=\"ERROR_MSG\">");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${msg}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
      out.write("</td>\r\n");
      out.write("  </tr>\r\n");
      out.write("  <tr align=\"center\">\r\n");
      out.write("    <td>&nbsp;</td>\r\n");
      out.write("    <td><button onClick=\"forward('c_serieslist.do')\">返回</button></td>\r\n");
      out.write("  </tr>\r\n");
      out.write("</table>\r\n");
      out.write("</form>\r\n");
      out.write("</body>\r\n");
      out.write("</html>\r\n");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
