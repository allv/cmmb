package org.apache.jsp.pages.train.volunteer;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;

public final class volunteermodify_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();

  private static java.util.List _jspx_dependants;

  static {
    _jspx_dependants = new java.util.ArrayList(1);
    _jspx_dependants.add("/pages/train/volunteer/../import.jsp");
  }

  private org.apache.jasper.runtime.TagHandlerPool _005fjspx_005ftagPool_005fc_005fif_0026_005ftest;

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.AnnotationProcessor _jsp_annotationprocessor;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _005fjspx_005ftagPool_005fc_005fif_0026_005ftest = org.apache.jasper.runtime.TagHandlerPool.getTagHandlerPool(getServletConfig());
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_annotationprocessor = (org.apache.AnnotationProcessor) getServletConfig().getServletContext().getAttribute(org.apache.AnnotationProcessor.class.getName());
  }

  public void _jspDestroy() {
    _005fjspx_005ftagPool_005fc_005fif_0026_005ftest.release();
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      response.setContentType("text/html; charset=UTF-8");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write('\r');
      out.write('\n');
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");

String path = request.getContextPath();
String basePath = request.getScheme()+"://"+request.getServerName()+":"+request.getServerPort()+path;

      out.write("\r\n");
      out.write("<link href=\"");
      out.print(basePath);
      out.write("/pages/train/skins/css/common.css\" rel=\"stylesheet\" type=\"text/css\" />\r\n");
      out.write("<script type=\"text/javascript\" src=\"");
      out.print(basePath);
      out.write("/js/md5.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\" src=\"");
      out.print(basePath);
      out.write("/js/jquery-1.3.2.min.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\" src=\"");
      out.print(basePath);
      out.write("/pages/train/js/check.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\" src=\"");
      out.print(basePath);
      out.write("/pages/train/js/LodopFuncs.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\" src=\"");
      out.print(basePath);
      out.write("/js/My97DatePicker/WdatePicker.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\" src=\"");
      out.print(basePath);
      out.write("/pages/train/js/common.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\" src=\"");
      out.print(basePath);
      out.write("/js/communication.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\" src=\"");
      out.print(basePath);
      out.write("/js/validate.js\"></script>\r\n");
      out.write("\r\n");
      out.write("<html>\r\n");
      out.write("<head>\r\n");
      out.write("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">\r\n");
      out.write("<title>修改志愿者信息</title>\r\n");
      out.write("<script type=\"text/javascript\">\r\n");
      out.write("var basePath = '");
      out.print(basePath);
      out.write("';\r\n");
      out.write("\r\n");
      out.write("function onSubmit()\r\n");
      out.write("{\r\n");
      out.write("    var vid = document.getElementById(\"vid\").value;\r\n");
      out.write("    var vname = document.getElementById(\"vname\").value;\r\n");
      out.write("    if(vname==\"\"){\r\n");
      out.write("        alert('姓名不能为空');\r\n");
      out.write("        return;\r\n");
      out.write("    }\r\n");
      out.write("   \tvar vage = document.getElementById(\"vage\").value;\r\n");
      out.write("   \tvar vgender = document.getElementById(\"vgender\").value;\r\n");
      out.write("   \tvar vgender = '男';\r\n");
      out.write("\t\tif(document.getElementById(\"vgender1\").checked==true){\r\n");
      out.write("\t\t    vgender='女';\r\n");
      out.write("\t\t}\r\n");
      out.write("   \tvar vphone = document.getElementById(\"vphone\").value;\r\n");
      out.write("   \tvar vspecialty = document.getElementById(\"vspecialty\").value;\r\n");
      out.write("   \tvar vcommunitywork = document.getElementById(\"vcommunitywork\").value;\r\n");
      out.write("    var vstudy = '是';\r\n");
      out.write("\t\tif(document.getElementById(\"vstudy1\").checked==true){\r\n");
      out.write("\t\t    vstudy='否';\r\n");
      out.write("\t\t}\r\n");
      out.write("   \tvar vintention = document.getElementById(\"vintention\").value;\r\n");
      out.write("   \tvar vtrain = document.getElementById(\"vtrain\").value;\r\n");
      out.write("    var item = vid + \"|\" + vname + \"|\" + vage + \"|\" + vgender + \"|\" + vphone + \"|\" + vspecialty + \"|\" + vcommunitywork + \"|\" + vstudy + \"|\" + vintention + \"|\" + vtrain;\r\n");
      out.write("       $.ajax({\r\n");
      out.write("\t\t\ttype : \"POST\",\r\n");
      out.write("\t\t\turl : basePath + \"/volunteermodifyvol.do?detail=\" + encodeURI(item),\r\n");
      out.write("\t\t\tsuccess : function(msg) {\r\n");
      out.write("\t\t\t\tvar result = msg;\r\n");
      out.write("\t\t\t\tif ('success' == result) {\r\n");
      out.write("\t\t\t\t\talert('修改志愿者成功');\r\n");
      out.write("\t\t\t\t\twindow.location.href = basePath + \"/volunteerlist.do\";\r\n");
      out.write("\t\t\t\t} else {\r\n");
      out.write("\t\t\t\t\talert('修改志愿者失败');\r\n");
      out.write("\t\t\t\t}\r\n");
      out.write("\t\t\t},\r\n");
      out.write("\t\t\tfailure : function() {\r\n");
      out.write("\t\t\t\talert(\"未知错误！\");\r\n");
      out.write("\t\t\t}\r\n");
      out.write("\t\t});\r\n");
      out.write("}\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("</script>\r\n");
      out.write("</head>\r\n");
      out.write("<body>\r\n");
      out.write("<div class=\"topLanBar\"><b>当前位置：</b>志愿者管理 >志愿者管理 > 修改增志愿者信息</div>\r\n");
      out.write("<table width=\"100%\">\r\n");
      out.write("  <tr>\r\n");
      out.write("    <td background=\"");
      out.print(basePath);
      out.write("/pages/train/skins/img/lan-index.gif\">&nbsp;</td>\r\n");
      out.write("  </tr>\r\n");
      out.write("</table>\r\n");
      out.write("<form  method=\"post\">\r\n");
      out.write("<table width=\"100%\" border=\"0\" cellpadding=\"3\" cellspacing=\"1\" id=\"tbody\">\r\n");
      out.write("    <tr>\r\n");
      out.write("    <input type=\"hidden\" name=\"vid\" value=\"");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${result.vid}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
      out.write("\" />\r\n");
      out.write("      <td align=\"right\">姓名</td>\r\n");
      out.write("      <td><input type=\"text\" name=\"vname\" value=\"");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${result.vname}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
      out.write("\"/><span style='color:red;'>&nbsp;*</span></td>\r\n");
      out.write("    </tr>\r\n");
      out.write("    <tr>\r\n");
      out.write("      <td align=\"right\">年龄</td>\r\n");
      out.write("      <td><input type=\"text\" name=\"vage\" value=\"");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${result.vage}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
      out.write("\"/></td>\r\n");
      out.write("    </tr>\r\n");
      out.write("    <tr>\r\n");
      out.write("      <td align=\"right\">性别</td>\r\n");
      out.write("      <td>\r\n");
      out.write("          ");
      if (_jspx_meth_c_005fif_005f0(_jspx_page_context))
        return;
      out.write("\r\n");
      out.write("\t\t         \r\n");
      out.write("\t\t                ");
      if (_jspx_meth_c_005fif_005f1(_jspx_page_context))
        return;
      out.write("\r\n");
      out.write("      </td>\r\n");
      out.write("    </tr>\r\n");
      out.write("    <tr>\r\n");
      out.write("      <td align=\"right\">电话</td>\r\n");
      out.write("      <td><input name=\"vphone\" type=\"text\" value=\"");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${result.vphone}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
      out.write("\"/></td>\r\n");
      out.write("    </tr>\r\n");
      out.write("    <tr>\r\n");
      out.write("      <td align=\"right\">是否有学习新知识意愿</td>\r\n");
      out.write("      <td>\r\n");
      out.write("         ");
      if (_jspx_meth_c_005fif_005f2(_jspx_page_context))
        return;
      out.write("\r\n");
      out.write("\t\t         \r\n");
      out.write("\t\t                ");
      if (_jspx_meth_c_005fif_005f3(_jspx_page_context))
        return;
      out.write("\r\n");
      out.write("      </td>\r\n");
      out.write("    </tr>\r\n");
      out.write("    <tr>\r\n");
      out.write("      <td align=\"right\">加入志愿服务日期</td>\r\n");
      out.write("      <td><input type=\"text\" size=\"\" name=\"vtrain\" value=\"");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${result.vtrain}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
      out.write("\" class=\"Wdate\" onClick=\"WdatePicker({dateFmt:'yyyy-MM-dd',readOnly:true})\" /></td>\r\n");
      out.write("    </tr>\r\n");
      out.write("    <tr>\r\n");
      out.write("      <td align=\"right\">个人特长</td>\r\n");
      out.write("       <td><textarea name=\"vspecialty\" cols=\"58\" rows=\"4\">");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${result.vspecialty}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
      out.write("</textarea></td>\r\n");
      out.write("    </tr>\r\n");
      out.write("    \r\n");
      out.write("    <tr>\r\n");
      out.write("      <td align=\"right\">社区工作经历</td>\r\n");
      out.write("      <td><textarea name=\"vcommunitywork\" cols=\"58\" rows=\"4\">");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${result.vcommunitywork}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
      out.write("</textarea></td>\r\n");
      out.write("    </tr>\r\n");
      out.write("   <tr>\r\n");
      out.write("      <td align=\"right\">志愿服务意向</td>\r\n");
      out.write("      <td><textarea name=\"vintention\" cols=\"58\" rows=\"4\">");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${result.vintention}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
      out.write("</textarea></td>\r\n");
      out.write("    </tr>\r\n");
      out.write("  </table>\r\n");
      out.write(" <table width=\"80%\" cellspacing=\"0\" cellpadding=\"1\">\r\n");
      out.write("     <tr>\r\n");
      out.write("     <td align=\"center\"><button onclick=\"onSubmit()\">提交</button> \r\n");
      out.write("\t\t<button onClick=\"forward('volunteerlist.do')\">返回</button></td>\r\n");
      out.write("     </tr>\r\n");
      out.write("</table>\r\n");
      out.write("</form>\r\n");
      out.write("<script type=\"text/javascript\">\r\n");
      out.write("var labels=document.getElementsByTagName('label');\r\n");
      out.write("var radios=new Array();\r\n");
      out.write("//得到所有radio类型的input\r\n");
      out.write("var allr=document.getElementsByTagName('input');\r\n");
      out.write("for(ir=0;ir<allr.length;ir++){\r\n");
      out.write("    if(allr[ir].type=='radio'){\r\n");
      out.write("        radios.push(allr[ir]);\r\n");
      out.write("    }\r\n");
      out.write("}\r\n");
      out.write("function initClass(labesindex,labeindex){\r\n");
      out.write("   for(i=labesindex,j=labeindex ; i<j ; i++)\r\n");
      out.write("   {\r\n");
      out.write("       labels[i].onclick=function() \r\n");
      out.write("       {\r\n");
      out.write("\t\t       for(k=labesindex,l=labeindex ; k<l ; k++)\r\n");
      out.write("\t\t       {\r\n");
      out.write("\t\t          labels[k].className='';\r\n");
      out.write("\t\t     \t  radios[k].checked = false;\r\n");
      out.write("\t\t       }\r\n");
      out.write("\t\t       this.className='checked';\r\n");
      out.write("\t\t       try{\r\n");
      out.write("\t\t    \t   document.getElementById(this.name).checked = true;\r\n");
      out.write("\t\t       }catch (e) {\r\n");
      out.write("\t\t           alert(e.getMessage());\r\n");
      out.write("\t\t       }\r\n");
      out.write("\t    }   \r\n");
      out.write("   }\r\n");
      out.write("}\r\n");
      out.write("initClass(0,2);\r\n");
      out.write("initClass(2,4);\r\n");
      out.write("</script>\r\n");
      out.write("</body>\r\n");
      out.write("</html>\r\n");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }

  private boolean _jspx_meth_c_005fif_005f0(PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  c:if
    org.apache.taglibs.standard.tag.rt.core.IfTag _jspx_th_c_005fif_005f0 = (org.apache.taglibs.standard.tag.rt.core.IfTag) _005fjspx_005ftagPool_005fc_005fif_0026_005ftest.get(org.apache.taglibs.standard.tag.rt.core.IfTag.class);
    _jspx_th_c_005fif_005f0.setPageContext(_jspx_page_context);
    _jspx_th_c_005fif_005f0.setParent(null);
    // /pages/train/volunteer/volunteermodify.jsp(76,10) name = test type = boolean reqTime = true required = true fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_c_005fif_005f0.setTest(((java.lang.Boolean) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${result.vgender eq '男'}", java.lang.Boolean.class, (PageContext)_jspx_page_context, null, false)).booleanValue());
    int _jspx_eval_c_005fif_005f0 = _jspx_th_c_005fif_005f0.doStartTag();
    if (_jspx_eval_c_005fif_005f0 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
      do {
        out.write("\r\n");
        out.write("\t\t             \t\t<input id=\"vgender\" name=\"vgender\" type=\"radio\" class=\"radio\" value=\"男\"  checked><label class=\"checked\" value=\"60\" name=\"vgender\" for=\"vgender\">男 &nbsp;&nbsp;&nbsp;</label>\r\n");
        out.write("\t\t        \t \t\t<input id=\"vgender1\" name=\"vgender\" type=\"radio\" class=\"radio\" value=\"女\" ><label class=\"\" value=\"61\" name=\"vgender1\" for=\"vgender1\">女</label>\r\n");
        out.write("\t\t                ");
        int evalDoAfterBody = _jspx_th_c_005fif_005f0.doAfterBody();
        if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
          break;
      } while (true);
    }
    if (_jspx_th_c_005fif_005f0.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _005fjspx_005ftagPool_005fc_005fif_0026_005ftest.reuse(_jspx_th_c_005fif_005f0);
      return true;
    }
    _005fjspx_005ftagPool_005fc_005fif_0026_005ftest.reuse(_jspx_th_c_005fif_005f0);
    return false;
  }

  private boolean _jspx_meth_c_005fif_005f1(PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  c:if
    org.apache.taglibs.standard.tag.rt.core.IfTag _jspx_th_c_005fif_005f1 = (org.apache.taglibs.standard.tag.rt.core.IfTag) _005fjspx_005ftagPool_005fc_005fif_0026_005ftest.get(org.apache.taglibs.standard.tag.rt.core.IfTag.class);
    _jspx_th_c_005fif_005f1.setPageContext(_jspx_page_context);
    _jspx_th_c_005fif_005f1.setParent(null);
    // /pages/train/volunteer/volunteermodify.jsp(81,18) name = test type = boolean reqTime = true required = true fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_c_005fif_005f1.setTest(((java.lang.Boolean) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${result.vgender eq '女'}", java.lang.Boolean.class, (PageContext)_jspx_page_context, null, false)).booleanValue());
    int _jspx_eval_c_005fif_005f1 = _jspx_th_c_005fif_005f1.doStartTag();
    if (_jspx_eval_c_005fif_005f1 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
      do {
        out.write("\r\n");
        out.write("\t\t         \t    \t<input id=\"vgender\" name=\"vgender\" type=\"radio\" class=\"radio\" value=\"男\" ><label class=\"\" value=\"60\" name=\"vgender\" for=\"vgender\">男 &nbsp;&nbsp;&nbsp;</label>\r\n");
        out.write("\t\t         \t\t\t<input id=\"vgender1\" name=\"vgender\" type=\"radio\" class=\"radio\" value=\"女\" checked><label class=\"checked\" value=\"61\" name=\"vgender1\" for=\"vgender1\">女</label>\r\n");
        out.write("\t\t        \t    ");
        int evalDoAfterBody = _jspx_th_c_005fif_005f1.doAfterBody();
        if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
          break;
      } while (true);
    }
    if (_jspx_th_c_005fif_005f1.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _005fjspx_005ftagPool_005fc_005fif_0026_005ftest.reuse(_jspx_th_c_005fif_005f1);
      return true;
    }
    _005fjspx_005ftagPool_005fc_005fif_0026_005ftest.reuse(_jspx_th_c_005fif_005f1);
    return false;
  }

  private boolean _jspx_meth_c_005fif_005f2(PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  c:if
    org.apache.taglibs.standard.tag.rt.core.IfTag _jspx_th_c_005fif_005f2 = (org.apache.taglibs.standard.tag.rt.core.IfTag) _005fjspx_005ftagPool_005fc_005fif_0026_005ftest.get(org.apache.taglibs.standard.tag.rt.core.IfTag.class);
    _jspx_th_c_005fif_005f2.setPageContext(_jspx_page_context);
    _jspx_th_c_005fif_005f2.setParent(null);
    // /pages/train/volunteer/volunteermodify.jsp(94,9) name = test type = boolean reqTime = true required = true fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_c_005fif_005f2.setTest(((java.lang.Boolean) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${result.vstudy eq '是'}", java.lang.Boolean.class, (PageContext)_jspx_page_context, null, false)).booleanValue());
    int _jspx_eval_c_005fif_005f2 = _jspx_th_c_005fif_005f2.doStartTag();
    if (_jspx_eval_c_005fif_005f2 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
      do {
        out.write("\r\n");
        out.write("\t\t             \t\t<input id=\"vstudy\" name=\"vstudy\" type=\"radio\" class=\"radio\" value=\"是\"  checked><label class=\"checked\" value=\"62\" name=\"vstudy\" for=\"vstudy\">是 &nbsp;&nbsp;&nbsp;</label>\r\n");
        out.write("\t\t        \t \t\t<input id=\"vstudy1\" name=\"vstudy\" type=\"radio\" class=\"radio\" value=\"否\" ><label class=\"\" value=\"63\" name=\"vstudy1\" for=\"vstudy1\">否</label>\r\n");
        out.write("\t\t                ");
        int evalDoAfterBody = _jspx_th_c_005fif_005f2.doAfterBody();
        if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
          break;
      } while (true);
    }
    if (_jspx_th_c_005fif_005f2.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _005fjspx_005ftagPool_005fc_005fif_0026_005ftest.reuse(_jspx_th_c_005fif_005f2);
      return true;
    }
    _005fjspx_005ftagPool_005fc_005fif_0026_005ftest.reuse(_jspx_th_c_005fif_005f2);
    return false;
  }

  private boolean _jspx_meth_c_005fif_005f3(PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  c:if
    org.apache.taglibs.standard.tag.rt.core.IfTag _jspx_th_c_005fif_005f3 = (org.apache.taglibs.standard.tag.rt.core.IfTag) _005fjspx_005ftagPool_005fc_005fif_0026_005ftest.get(org.apache.taglibs.standard.tag.rt.core.IfTag.class);
    _jspx_th_c_005fif_005f3.setPageContext(_jspx_page_context);
    _jspx_th_c_005fif_005f3.setParent(null);
    // /pages/train/volunteer/volunteermodify.jsp(99,18) name = test type = boolean reqTime = true required = true fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_c_005fif_005f3.setTest(((java.lang.Boolean) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${result.vstudy eq '否'}", java.lang.Boolean.class, (PageContext)_jspx_page_context, null, false)).booleanValue());
    int _jspx_eval_c_005fif_005f3 = _jspx_th_c_005fif_005f3.doStartTag();
    if (_jspx_eval_c_005fif_005f3 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
      do {
        out.write("\r\n");
        out.write("\t\t         \t    \t<input id=\"vstudy\" name=\"vstudy\" type=\"radio\" class=\"radio\" value=\"是\" ><label class=\"\" value=\"62\" name=\"vstudy\" for=\"vstudy\">是 &nbsp;&nbsp;&nbsp;</label>\r\n");
        out.write("\t\t         \t\t\t<input id=\"vstudy1\" name=\"vstudy\" type=\"radio\" class=\"radio\" value=\"否\" checked><label class=\"checked\" value=\"63\" name=\"vstudy1\" for=\"vstudy1\">否</label>\r\n");
        out.write("\t\t        \t    ");
        int evalDoAfterBody = _jspx_th_c_005fif_005f3.doAfterBody();
        if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
          break;
      } while (true);
    }
    if (_jspx_th_c_005fif_005f3.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _005fjspx_005ftagPool_005fc_005fif_0026_005ftest.reuse(_jspx_th_c_005fif_005f3);
      return true;
    }
    _005fjspx_005ftagPool_005fc_005fif_0026_005ftest.reuse(_jspx_th_c_005fif_005f3);
    return false;
  }
}
