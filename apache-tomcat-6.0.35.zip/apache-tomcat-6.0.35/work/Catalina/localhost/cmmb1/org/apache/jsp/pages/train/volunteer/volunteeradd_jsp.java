package org.apache.jsp.pages.train.volunteer;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;

public final class volunteeradd_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();

  private static java.util.List _jspx_dependants;

  static {
    _jspx_dependants = new java.util.ArrayList(1);
    _jspx_dependants.add("/pages/train/volunteer/../import.jsp");
  }

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.AnnotationProcessor _jsp_annotationprocessor;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_annotationprocessor = (org.apache.AnnotationProcessor) getServletConfig().getServletContext().getAttribute(org.apache.AnnotationProcessor.class.getName());
  }

  public void _jspDestroy() {
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      response.setContentType("text/html; charset=UTF-8");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write('\r');
      out.write('\n');
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");

String path = request.getContextPath();
String basePath = request.getScheme()+"://"+request.getServerName()+":"+request.getServerPort()+path;

      out.write("\r\n");
      out.write("<link href=\"");
      out.print(basePath);
      out.write("/pages/train/skins/css/common.css\" rel=\"stylesheet\" type=\"text/css\" />\r\n");
      out.write("<script type=\"text/javascript\" src=\"");
      out.print(basePath);
      out.write("/js/md5.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\" src=\"");
      out.print(basePath);
      out.write("/js/jquery-1.3.2.min.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\" src=\"");
      out.print(basePath);
      out.write("/pages/train/js/check.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\" src=\"");
      out.print(basePath);
      out.write("/pages/train/js/LodopFuncs.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\" src=\"");
      out.print(basePath);
      out.write("/js/My97DatePicker/WdatePicker.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\" src=\"");
      out.print(basePath);
      out.write("/pages/train/js/common.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\" src=\"");
      out.print(basePath);
      out.write("/js/communication.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\" src=\"");
      out.print(basePath);
      out.write("/js/validate.js\"></script>\r\n");
      out.write("\r\n");
      out.write("<html>\r\n");
      out.write("<head>\r\n");
      out.write("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">\r\n");
      out.write("<title>新增志愿者</title>\r\n");
      out.write("<script type=\"text/javascript\">\r\n");
      out.write("var basePath = '");
      out.print(basePath);
      out.write("';\r\n");
      out.write("var $2 = function(id){\r\n");
      out.write("        return document.getElementById(id);\r\n");
      out.write("    }\r\n");
      out.write("    //保存\r\n");
      out.write("    function Save() {\r\n");
      out.write("        var vname = document.getElementById(\"vname\").value;\r\n");
      out.write("        if(vname==\"\"){\r\n");
      out.write("       \t \talert('姓名不能为空');\r\n");
      out.write("        \treturn;\r\n");
      out.write("    \t}\r\n");
      out.write("    \tvar vage = document.getElementById(\"vage\").value;\r\n");
      out.write("    \tvar vgender = '男';\r\n");
      out.write("\t\tif(document.getElementById(\"vgender1\").checked==true){\r\n");
      out.write("\t\t    vgender='女';\r\n");
      out.write("\t\t}\r\n");
      out.write("    \tvar vphone = document.getElementById(\"vphone\").value;\r\n");
      out.write("    \tvar vspecialty = document.getElementById(\"vspecialty\").value;\r\n");
      out.write("    \tvar vcommunitywork = document.getElementById(\"vcommunitywork\").value;\r\n");
      out.write("    \tvar vstudy = '是';\r\n");
      out.write("\t\tif(document.getElementById(\"vstudy1\").checked==true){\r\n");
      out.write("\t\t    vstudy='否';\r\n");
      out.write("\t\t}\r\n");
      out.write("    \tvar vintention = document.getElementById(\"vintention\").value;\r\n");
      out.write("    \tvar vtrain = document.getElementById(\"vtrain\").value;\r\n");
      out.write("        var item = vname + \"|\" + vage + \"|\" + vgender + \"|\" + vphone + \"|\" + vspecialty + \"|\" + vcommunitywork + \"|\" + vstudy + \"|\" + vintention + \"|\" + vtrain;\r\n");
      out.write("        $2(\"detail\").value = item;\r\n");
      out.write("        \r\n");
      out.write("        $.ajax({\r\n");
      out.write("\t\t\t\t\ttype : \"POST\",\r\n");
      out.write("\t\t\t\t\turl : basePath + \"/volunteersaveVolunteer.do?detail=\" + encodeURI(item),\r\n");
      out.write("\t\t\t\t\tsuccess : function(msg) {\r\n");
      out.write("\t\t\t\t\t\tvar result = msg;\r\n");
      out.write("\t\t\t\t\t\tif ('success' == result) {\r\n");
      out.write("\t\t\t\t\t\t\talert('新增志愿者成功');\r\n");
      out.write("\t\t\t\t\t\t\twindow.location.href = basePath + \"/volunteerlist.do\";\r\n");
      out.write("\t\t\t\t\t\t} else {\r\n");
      out.write("\t\t\t\t\t\t\talert('新增志愿者失败');\r\n");
      out.write("\t\t\t\t\t\t}\r\n");
      out.write("\t\t\t\t\t},\r\n");
      out.write("\t\t\t\t\tfailure : function() {\r\n");
      out.write("\t\t\t\t\t\talert(\"未知错误！\");\r\n");
      out.write("\t\t\t\t\t}\r\n");
      out.write("\t\t\t\t});\r\n");
      out.write("    }\r\n");
      out.write("</script>\r\n");
      out.write("</head>\r\n");
      out.write("<body>\r\n");
      out.write("<div class=\"topLanBar\"><b>当前位置：</b>志愿者管理 >志愿者管理 > 新增志愿者</div>\r\n");
      out.write("<table width=\"100%\">\r\n");
      out.write("  <tr>\r\n");
      out.write("    <td background=\"");
      out.print(basePath);
      out.write("/pages/train/skins/img/lan-index.gif\">&nbsp;</td>\r\n");
      out.write("  </tr>\r\n");
      out.write("</table>\r\n");
      out.write("<form name=\"myform\"  method=\"post\" action=\"volunteersaveVolunteer.do\">\r\n");
      out.write("<input type=\"hidden\" id=\"detail\" name=\"detail\" />\r\n");
      out.write("<table  width=\"100%\" border=\"0\" cellpadding=\"3\" cellspacing=\"1\">\r\n");
      out.write("    <tr>\r\n");
      out.write("      <td align=\"right\">姓名</td>\r\n");
      out.write("      <td><input type=\"text\" name=\"vname\" value=\"");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${vname}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
      out.write("\"/><span style='color:red;'>&nbsp;*</span></td>\r\n");
      out.write("    </tr>\r\n");
      out.write("    <tr>\r\n");
      out.write("      <td align=\"right\">年龄</td>\r\n");
      out.write("      <td><input type=\"text\" name=\"vage\" value=\"");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${vage}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
      out.write("\"/>\r\n");
      out.write("      </td>\r\n");
      out.write("    </tr>\r\n");
      out.write("    <tr>\r\n");
      out.write("      <td align=\"right\">性别</td>\r\n");
      out.write("      <td>\r\n");
      out.write("          <input id=\"vgender\" name=\"vgender\" class=\"radio\" type=\"radio\" value=\"男\" checked><label class=\"checked\" value=\"60\" name=\"vgender\" for=\"vgender\">男 &nbsp;&nbsp;&nbsp;</label>\r\n");
      out.write("          <input id=\"vgender1\" name=\"vgender\" class=\"radio\" type=\"radio\" value=\"女\"><label class=\"\" value=\"61\" name=\"vgender1\" for=\"vgender1\">女</label>\r\n");
      out.write("      </td>\r\n");
      out.write("    </tr>\r\n");
      out.write("    <tr>\r\n");
      out.write("      <td align=\"right\">电话</td>\r\n");
      out.write("      <td><input name=\"vphone\" type=\"text\" value=\"");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${vphone}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
      out.write("\"/></td>\r\n");
      out.write("    </tr>\r\n");
      out.write("    <tr>\r\n");
      out.write("      <td align=\"right\">是否有学习新知识意愿</td>\r\n");
      out.write("      <td>\r\n");
      out.write("          <input id=\"vstudy\" name=\"vstudy\" class=\"radio\" type=\"radio\" value=\"是\" checked><label class=\"checked\" value=\"62\" name=\"vstudy\" for=\"vstudy\">是 &nbsp;&nbsp;&nbsp;</label>\r\n");
      out.write("          <input id=\"vstudy1\" name=\"vstudy\" class=\"radio\" type=\"radio\" value=\"否\"><label class=\"\" value=\"63\" name=\"vstudy1\" for=\"vstudy1\">否</label>\r\n");
      out.write("      </td>\r\n");
      out.write("    </tr>\r\n");
      out.write("    <tr>\r\n");
      out.write("      <td align=\"right\">加入志愿服务日期</td>\r\n");
      out.write("      <td><input type=\"text\" size=\"\" name=\"vtrain\" value=\"\" class=\"Wdate\" onClick=\"WdatePicker({dateFmt:'yyyy-MM-dd',readOnly:true})\" /></td>\r\n");
      out.write("    </tr>\r\n");
      out.write("    <tr>\r\n");
      out.write("      <td align=\"right\">个人特长</td>\r\n");
      out.write("       <td><textarea name=\"vspecialty\" cols=\"58\" rows=\"4\">");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${vspecialty}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
      out.write("</textarea></td>\r\n");
      out.write("    </tr>\r\n");
      out.write("    \r\n");
      out.write("    <tr>\r\n");
      out.write("      <td align=\"right\">社区工作经历</td>\r\n");
      out.write("      <td><textarea name=\"vcommunitywork\" cols=\"58\" rows=\"4\">");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${vcommunitywork}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
      out.write("</textarea></td>\r\n");
      out.write("    </tr>\r\n");
      out.write("   <tr>\r\n");
      out.write("      <td align=\"right\">志愿服务意向</td>\r\n");
      out.write("      <td><textarea name=\"vintention\" cols=\"58\" rows=\"4\">");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${vintention}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
      out.write("</textarea></td>\r\n");
      out.write("    </tr>\r\n");
      out.write("</table>\r\n");
      out.write("<table width=\"80%\" cellspacing=\"0\" cellpadding=\"1\">\r\n");
      out.write("     <tr>\r\n");
      out.write("     <td align=\"center\"><button onclick=\"Save()\">提交</button> \r\n");
      out.write("\t\t<button onClick=\"forward('volunteerlist.do')\">返回</button></td>\r\n");
      out.write("    </tr>\r\n");
      out.write("</table>\r\n");
      out.write("</form>\r\n");
      out.write("<script type=\"text/javascript\">\r\n");
      out.write("var labels=document.getElementsByTagName('label');\r\n");
      out.write("var radios=new Array();\r\n");
      out.write("//得到所有radio类型的input\r\n");
      out.write("var allr=document.getElementsByTagName('input');\r\n");
      out.write("for(ir=0;ir<allr.length;ir++){\r\n");
      out.write("    if(allr[ir].type=='radio'){\r\n");
      out.write("        radios.push(allr[ir]);\r\n");
      out.write("    }\r\n");
      out.write("}\r\n");
      out.write("function initClass(labesindex,labeindex){\r\n");
      out.write("   for(i=labesindex,j=labeindex ; i<j ; i++)\r\n");
      out.write("   {\r\n");
      out.write("       labels[i].onclick=function() \r\n");
      out.write("       {\r\n");
      out.write("\t\t       for(k=labesindex,l=labeindex ; k<l ; k++)\r\n");
      out.write("\t\t       {\r\n");
      out.write("\t\t          labels[k].className='';\r\n");
      out.write("\t\t     \t  radios[k].checked = false;\r\n");
      out.write("\t\t       }\r\n");
      out.write("\t\t       this.className='checked';\r\n");
      out.write("\t\t       try{\r\n");
      out.write("\t\t    \t   document.getElementById(this.name).checked = true;\r\n");
      out.write("\t\t       }catch (e) {\r\n");
      out.write("\t\t           alert(e.getMessage());\r\n");
      out.write("\t\t       }\r\n");
      out.write("\t    }   \r\n");
      out.write("   }\r\n");
      out.write("   labels[labesindex].click();\r\n");
      out.write("}\r\n");
      out.write("initClass(0,2);\r\n");
      out.write("initClass(2,4);\r\n");
      out.write("</script>\r\n");
      out.write("</body>\r\n");
      out.write("</html>\r\n");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
