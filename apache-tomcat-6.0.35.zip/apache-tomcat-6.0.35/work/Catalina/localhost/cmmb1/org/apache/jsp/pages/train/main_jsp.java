package org.apache.jsp.pages.train;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;

public final class main_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();

  private static java.util.List _jspx_dependants;

  static {
    _jspx_dependants = new java.util.ArrayList(1);
    _jspx_dependants.add("/pages/train/import.jsp");
  }

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.AnnotationProcessor _jsp_annotationprocessor;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_annotationprocessor = (org.apache.AnnotationProcessor) getServletConfig().getServletContext().getAttribute(org.apache.AnnotationProcessor.class.getName());
  }

  public void _jspDestroy() {
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      response.setContentType("text/html; charset=UTF-8");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write('\r');
      out.write('\n');
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");

String path = request.getContextPath();
String basePath = request.getScheme()+"://"+request.getServerName()+":"+request.getServerPort()+path;

      out.write("\r\n");
      out.write("<link href=\"");
      out.print(basePath);
      out.write("/pages/train/skins/css/common.css\" rel=\"stylesheet\" type=\"text/css\" />\r\n");
      out.write("<script type=\"text/javascript\" src=\"");
      out.print(basePath);
      out.write("/js/md5.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\" src=\"");
      out.print(basePath);
      out.write("/js/jquery-1.3.2.min.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\" src=\"");
      out.print(basePath);
      out.write("/pages/train/js/check.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\" src=\"");
      out.print(basePath);
      out.write("/pages/train/js/LodopFuncs.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\" src=\"");
      out.print(basePath);
      out.write("/js/My97DatePicker/WdatePicker.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\" src=\"");
      out.print(basePath);
      out.write("/pages/train/js/common.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\" src=\"");
      out.print(basePath);
      out.write("/js/communication.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\" src=\"");
      out.print(basePath);
      out.write("/js/validate.js\"></script>\r\n");
      out.write("\r\n");
      out.write("<html>\r\n");
      out.write("<head>\r\n");
      out.write("<meta http-equiv=\"pragma\" content=\"no-cache\">\r\n");
      out.write("<meta http-equiv=\"cache-control\" content=\"no-cache\">\r\n");
      out.write("<meta http-equiv=\"expires\" content=\"0\">\r\n");
      out.write("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">\r\n");
      out.write("<title>HBJJ伙伴聚家办公平台</title>\r\n");
      out.write("<style type=\"text/css\">\r\n");
      out.write("<!--\r\n");
      out.write("BODY {\r\n");
      out.write("\tmargin: 0px;\r\n");
      out.write("\toverflow: hidden;\r\n");
      out.write("}\r\n");
      out.write("#top {\r\n");
      out.write("\tbackground-image: url(");
      out.print(basePath);
      out.write("/pages/train/skins/img/greenline.png);\r\n");
      out.write("\tbackground-repeat: repeat-x;\r\n");
      out.write("\theight: 98px;\r\n");
      out.write("}\r\n");
      out.write("#top #top_bar_font {\r\n");
      out.write("\tcolor: #FFFFFF;\r\n");
      out.write("}\r\n");
      out.write("#top #top_bar_yl {\r\n");
      out.write("\tbackground-color: #FFCC00;\r\n");
      out.write("\theight: 6px;\r\n");
      out.write("}\r\n");
      out.write("#top #logo_font_CN {\r\n");
      out.write("\tfont-family: \"黑体\";\r\n");
      out.write("\tfont-size: 22px;\r\n");
      out.write("\tfont-weight: bold;\r\n");
      out.write("\tcolor: #FFFFFF;\r\n");
      out.write("\tfilter: DropShadow(Color = #cccccc, OffX = 1, OffY = 1, Positive = 20);\r\n");
      out.write("}\r\n");
      out.write("#top #logo_font_EN {\r\n");
      out.write("\tfont-family: Verdana, Arial, Helvetica, sans-serif;\r\n");
      out.write("\tcolor: #E0E0E0;\r\n");
      out.write("\tfont-size: 14px;\r\n");
      out.write("\tfont-weight: bold;\r\n");
      out.write("\tfilter: DropShadow(Color = #cccccc, OffX = 1, OffY = 1, Positive = 20);\r\n");
      out.write("}\r\n");
      out.write("#top a {\r\n");
      out.write("\tfont-weight: bold;\r\n");
      out.write("\tcolor: #FFCC00;\r\n");
      out.write("}\r\n");
      out.write("#top #webcome_font {\r\n");
      out.write("\tcolor: #FFFFFF;\r\n");
      out.write("\tbackground-color: #000000;\r\n");
      out.write("\ttext-align: center;\r\n");
      out.write("}\r\n");
      out.write("#top #webcome_font a {\r\n");
      out.write("\tcolor: #FF9900;\r\n");
      out.write("\tbackground-image: none;\r\n");
      out.write("\theight: 20px;\r\n");
      out.write("\twidth: 40px;\r\n");
      out.write("}\r\n");
      out.write("#onMenuImg {\r\n");
      out.write("\tcursor: hand;\r\n");
      out.write("}\r\n");
      out.write("#corpRight {\r\n");
      out.write("\tbackground-color: #66DD00;\r\n");
      out.write("\ttext-align: center;\r\n");
      out.write("\theight: 22px;\r\n");
      out.write("\tfont-family: Verdana, Arial, Helvetica, sans-serif;\r\n");
      out.write("\tcolor: #FFFFFF;\r\n");
      out.write("}\r\n");
      out.write("#menuBox {\r\n");
      out.write("\twidth: 180px;\r\n");
      out.write("}\r\n");
      out.write("-->\r\n");
      out.write("</style>\r\n");
      out.write("<script type=\"text/javascript\">\r\n");
      out.write("function optionLanBar(){\r\n");
      out.write("\tvar menuBox = document.getElementById(\"menuBox\");\r\n");
      out.write("\tvar imgLanBar = document.getElementById(\"imgLanBar\");\r\n");
      out.write("\tif(menuBox.style.display==\"none\"){\r\n");
      out.write("\t\tmenuBox.style.display=\"\";\r\n");
      out.write("\t\timgLanBar.src=\"");
      out.print(basePath);
      out.write("/pages/train/skins/img/lan-left.gif\";\r\n");
      out.write("\t}else{\r\n");
      out.write("\t\tmenuBox.style.display=\"none\";\r\n");
      out.write("\t\timgLanBar.src=\"");
      out.print(basePath);
      out.write("/pages/train/skins/img/lan-right.gif\";\r\n");
      out.write("\t}\r\n");
      out.write("}\r\n");
      out.write("function RunOnBeforeUnload()\r\n");
      out.write("{\r\n");
      out.write("\t var connout = new Connection();\r\n");
      out.write("\t connout.init(\"");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${pageContext.request.contextPath}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
      out.write("/douserlogout.do\");\r\n");
      out.write("\t connout.send(\"\",null);\r\n");
      out.write("}\r\n");
      out.write("</script>\r\n");
      out.write("</head>\r\n");
      out.write("<body onbeforeunload=\"RunOnBeforeUnload()\">\r\n");
      out.write("<table width=\"100%\" height=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">\r\n");
      out.write("  <tr>\r\n");
      out.write("    <td height=\"1\"><table id=\"top\" width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\r\n");
      out.write("        <tr>\r\n");
      out.write("          <td><table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\r\n");
      out.write("              <tr>\r\n");
      out.write("                <td><table width=\"500\" border=\"0\" cellspacing=\"0\" cellpadding=\"8\">\r\n");
      out.write("                    <tr>\r\n");
      out.write("                      <td><table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"3\">\r\n");
      out.write("                          <tr>\r\n");
      out.write("                            <td id=\"logo_font_CN\">HBJJ伙伴聚家办公平台</td>\r\n");
      out.write("                          </tr>\r\n");
      out.write("                          <tr>\r\n");
      out.write("                            <td id=\"logo_font_EN\">HBJJ Office Management Platform</td>\r\n");
      out.write("                          </tr>\r\n");
      out.write("                        </table></td>\r\n");
      out.write("                    </tr>\r\n");
      out.write("                  </table></td>\r\n");
      out.write("              </tr>\r\n");
      out.write("            </table></td>\r\n");
      out.write("        </tr>\r\n");
      out.write("        <tr>\r\n");
      out.write("          <td bgcolor=\"#000000\"><table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"5\">\r\n");
      out.write("              <tr>\r\n");
      out.write("                <td id=\"top_bar_font\">");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${nowDate}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
      out.write(' ');
      out.write('｜');
      out.write(' ');
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${username}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
      out.write("，欢迎您登录系统。\r\n");
      out.write("                <td align=\"right\" id=\"top_bar_font\">\r\n");
      out.write("                <a target=\"main\" href=\"welcome.do\">首页</a> ｜\r\n");
      out.write("                <a target=\"main\" href=\"uppassword.do\">修改密码</a> ｜\r\n");
      out.write("                <a href=\"logout.do\">注销</a></td>\r\n");
      out.write("              </tr>\r\n");
      out.write("            </table></td>\r\n");
      out.write("        </tr>\r\n");
      out.write("        <tr>\r\n");
      out.write("          <td id=\"top_bar_yl\"></td>\r\n");
      out.write("        </tr>\r\n");
      out.write("      </table></td>\r\n");
      out.write("  </tr>\r\n");
      out.write("  <tr>\r\n");
      out.write("    <td><table width=\"100%\" height=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">\r\n");
      out.write("        <tr>\r\n");
      out.write("          <td id=\"menuBox\"><iframe name=\"menu\" src=\"menu.do\" scrolling=\"no\"></iframe></td>\r\n");
      out.write("          <td width=\"1\" background=\"");
      out.print(basePath);
      out.write("/pages/train/skins/img/ctrl_bg.gif\" id=\"LanBar\"><img src=\"");
      out.print(basePath);
      out.write("/pages/train/skins/img/lan-left.gif\" name=\"imgLanBar\" id=\"imgLanBar\" onClick=\"optionLanBar()\"></td>\r\n");
      out.write("          <td><iframe name=\"main\" src=\"welcome.do\" scrolling=\"yes\"></iframe></td>\r\n");
      out.write("        </tr>\r\n");
      out.write("      </table></td>\r\n");
      out.write("  </tr>\r\n");
      out.write("  <tr>\r\n");
      out.write("    <td id=\"corpRight\">&copy; 2012-2013 HBJJ Corporation, All Rights Reserved.</td>\r\n");
      out.write("  </tr>\r\n");
      out.write("</table>\r\n");
      out.write("<script language=\"JavaScript\" type=\"text/javascript\">\r\n");
      out.write("       var sh;//定时器\r\n");
      out.write("       var num=0;\r\n");
      out.write("       sh = setInterval(\"testT()\",30000);//设置定时器，此处定时每1秒钟都会调用testT()函数\r\n");
      out.write("       //定时器执行函数\r\n");
      out.write("       function testT()\r\n");
      out.write("       {\r\n");
      out.write("       \t\t //去掉告警功能\r\n");
      out.write("       }\r\n");
      out.write("\r\n");
      out.write("       //$(window).unload( function () { alert(\"Bye now!\"); } );\r\n");
      out.write("    </script>\r\n");
      out.write("</body>\r\n");
      out.write("</html>\r\n");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
