package org.apache.jsp.pages.train.careservices;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import java.util.*;
import com.wootion.idp.view.vo.FordNagativation;

public final class othercareservicesadd_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();

  private static java.util.List _jspx_dependants;

  static {
    _jspx_dependants = new java.util.ArrayList(1);
    _jspx_dependants.add("/pages/train/careservices/../import.jsp");
  }

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.AnnotationProcessor _jsp_annotationprocessor;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_annotationprocessor = (org.apache.AnnotationProcessor) getServletConfig().getServletContext().getAttribute(org.apache.AnnotationProcessor.class.getName());
  }

  public void _jspDestroy() {
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      response.setContentType("text/html; charset=UTF-8");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write('\r');
      out.write('\n');
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");

String path = request.getContextPath();
String basePath = request.getScheme()+"://"+request.getServerName()+":"+request.getServerPort()+path;

      out.write("\r\n");
      out.write("<link href=\"");
      out.print(basePath);
      out.write("/pages/train/skins/css/common.css\" rel=\"stylesheet\" type=\"text/css\" />\r\n");
      out.write("<script type=\"text/javascript\" src=\"");
      out.print(basePath);
      out.write("/js/md5.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\" src=\"");
      out.print(basePath);
      out.write("/js/jquery-1.3.2.min.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\" src=\"");
      out.print(basePath);
      out.write("/pages/train/js/check.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\" src=\"");
      out.print(basePath);
      out.write("/js/My97DatePicker/WdatePicker.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\" src=\"");
      out.print(basePath);
      out.write("/pages/train/js/common.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\" src=\"");
      out.print(basePath);
      out.write("/js/communication.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\" src=\"");
      out.print(basePath);
      out.write("/js/validate.js\"></script>\r\n");
      out.write("\r\n");
      out.write("<html>\r\n");
      out.write("<head>\r\n");
      out.write("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">\r\n");
      out.write("<title>新增其他介护服务记录</title>\r\n");
      out.write("<script type=\"text/javascript\">\r\n");
      out.write("var basePath = '");
      out.print(basePath);
      out.write("';\r\n");
      out.write("var $2 = function(id){\r\n");
      out.write("        return document.getElementById(id);\r\n");
      out.write("    }\r\n");
      out.write("\r\n");
      out.write("    //全选\r\n");
      out.write("    function checkAll(target) {\r\n");
      out.write("        var checkeds = document.getElementsByName(\"b_id\");\r\n");
      out.write("        for (var i = 0; i < checkeds.length; i++) {\r\n");
      out.write("            checkeds[i].checked = target.checked;\r\n");
      out.write("        }\r\n");
      out.write("    }\r\n");
      out.write("\r\n");
      out.write("    //刷新行号\r\n");
      out.write("    function refreshRowNo() {\r\n");
      out.write("        var tbody = $2(\"tbody\");\r\n");
      out.write("        for (var i = 0; i < tbody.rows.length; i++) {\r\n");
      out.write("            tbody.rows[i].cells[0].innerHTML = i + 1;\r\n");
      out.write("        }\r\n");
      out.write("    }\r\n");
      out.write("\r\n");
      out.write("    //添加行\r\n");
      out.write("    function AddRow() {\r\n");
      out.write("        var tbody = $2(\"tbody\");\r\n");
      out.write("        var row = tbody.insertRow(tbody.rows.length);\r\n");
      out.write("        row.insertCell(row.cells.length);\r\n");
      out.write("        row.setAttribute(\"align\",\"center\");\r\n");
      out.write("        row.insertCell(row.cells.length).innerHTML = \"<input type='checkbox' class='checkBox1' name='b_id' />\";\r\n");
      out.write("        row.insertCell(row.cells.length).innerHTML = \"<input type='text' size='21' name='odate' value='' class='Wdate' onClick=\\\"WdatePicker({dateFmt:'yyyy-MM-dd',readOnly:true})\\\" />\";\r\n");
      out.write("        row.insertCell(row.cells.length).innerHTML = \"<input name='oname' type='text' value='");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${oname}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
      out.write("' size='22' onclick='chooseElders()' readonly/>\";\r\n");
      out.write("        row.insertCell(row.cells.length).innerHTML = \"<input name='ocontent' type='text' value='");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${ocontent}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
      out.write("' size='19'/>\";\r\n");
      out.write("        row.insertCell(row.cells.length).innerHTML = \"<input type='text' size='21' name='ostarttime' value='' class='Wdate' onClick=\\\"WdatePicker({dateFmt:'HH:mm:ss',readOnly:true})\\\" />\";\r\n");
      out.write("        row.insertCell(row.cells.length).innerHTML = \"<input type='text' size='21' name='oendtime' value='' class='Wdate' onClick=\\\"WdatePicker({dateFmt:'HH:mm:ss',readOnly:true})\\\" />\";\r\n");
      out.write("        row.insertCell(row.cells.length).innerHTML = \"<input name='opeople' type='text' value='");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${opeople}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
      out.write("' size='19'/>\";\r\n");
      out.write("        row.insertCell(row.cells.length).innerHTML = \"<input name='oevaluation' type='text' value='");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${oevaluation}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
      out.write("' size='19'/>\";\r\n");
      out.write("        row.insertCell(row.cells.length).innerHTML = \"<textarea name='oinfo' cols='34' onBlur=\\\"javascript:this.style.width='186px';this.style.height='21px';\\\" onFocus=\\\"javascript:this.style.width='186px';this.style.height='90px';\\\" rows='1'>");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${oinfo}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
      out.write("</textarea>\";\r\n");
      out.write("        \r\n");
      out.write("        refreshRowNo();\r\n");
      out.write("    }\r\n");
      out.write("\r\n");
      out.write("    //删除行\r\n");
      out.write("    function DelRow() {\r\n");
      out.write("        var checkeds = document.getElementsByName(\"b_id\");\r\n");
      out.write("        var ischeck = false;\r\n");
      out.write("        for (var i = checkeds.length - 1; i >= 0; i--) {\r\n");
      out.write("            if (checkeds[i].checked) {\r\n");
      out.write("                ischeck = true;\r\n");
      out.write("                break;\r\n");
      out.write("            }\r\n");
      out.write("        }\r\n");
      out.write("        if (ischeck) {\r\n");
      out.write("            if (confirm(\"确定删除选中行?\")) {\r\n");
      out.write("                for (var i = checkeds.length - 1; i >= 0; i--) {\r\n");
      out.write("                    if (checkeds[i].checked) {\r\n");
      out.write("                        var index = checkeds[i].parentNode.parentNode.rowIndex;\r\n");
      out.write("                        $2(\"tbody\").deleteRow(index - 1);\r\n");
      out.write("                    }\r\n");
      out.write("                }\r\n");
      out.write("                refreshRowNo();\r\n");
      out.write("            }\r\n");
      out.write("        } else {\r\n");
      out.write("            alert(\"请选中需要删除的行!\");\r\n");
      out.write("        }\r\n");
      out.write("    } \r\n");
      out.write("\r\n");
      out.write(" function choosePro(){\r\n");
      out.write("    var pname = \"obelongpro\";\r\n");
      out.write("    var wWidth = 1040;\r\n");
      out.write("    var wHeight = 510;\r\n");
      out.write("    var wTop = (window.screen.height - wHeight)/2;\r\n");
      out.write("    var wLeft = (window.screen.width - wWidth)/2;\r\n");
      out.write("    var obj = new Object();\r\n");
      out.write("    obj.name=pname;\r\n");
      out.write("    \r\n");
      out.write("    var url =  basePath + \"/proquery.do\";\r\n");
      out.write("    str = window.showModalDialog(url,obj,\"dialogWidth=500px;dialogHeight=400px\"); \r\n");
      out.write("    arr = str.split(\",\");\r\n");
      out.write("    //window.open(url,\"\",\"Height=400px,Width=500px\");\r\n");
      out.write("    if(typeof(str)==\"undefined\"){\r\n");
      out.write("        document.getElementById(pname).value=\"\";\r\n");
      out.write("    }else if(str==\"nochange\"){\r\n");
      out.write("        //document.getElementById(cid).value\r\n");
      out.write("    }else{\r\n");
      out.write("    \tdocument.getElementById(pname).value=arr[0];\r\n");
      out.write("    \tdocument.getElementById(\"startdate\").value=arr[2];\r\n");
      out.write("    \tdocument.getElementById(\"enddate\").value=arr[3];\r\n");
      out.write("    }\r\n");
      out.write("    \t\r\n");
      out.write("  }  \r\n");
      out.write("\r\n");
      out.write("    Date.prototype.format = function(format)\r\n");
      out.write("\t{\r\n");
      out.write("\t    var o =\r\n");
      out.write("\t    {\r\n");
      out.write("\t        \"M+\" : this.getMonth()+1, //month\r\n");
      out.write("\t        \"d+\" : this.getDate(),    //day\r\n");
      out.write("\t        \"h+\" : this.getHours(),   //hour\r\n");
      out.write("\t        \"m+\" : this.getMinutes(), //minute\r\n");
      out.write("\t        \"s+\" : this.getSeconds(), //second\r\n");
      out.write("\t        \"q+\" : Math.floor((this.getMonth()+3)/3),  //quarter\r\n");
      out.write("\t        \"S\" : this.getMilliseconds() //millisecond\r\n");
      out.write("\t    }\r\n");
      out.write("\t    if(/(y+)/.test(format))\r\n");
      out.write("\t    format=format.replace(RegExp.$1,(this.getFullYear()+\"\").substr(4 - RegExp.$1.length));\r\n");
      out.write("\t    for(var k in o)\r\n");
      out.write("\t    if(new RegExp(\"(\"+ k +\")\").test(format))\r\n");
      out.write("\t    format = format.replace(RegExp.$1,RegExp.$1.length==1 ? o[k] : (\"00\"+ o[k]).substr((\"\"+ o[k]).length));\r\n");
      out.write("\t    return format;\r\n");
      out.write("\t}\r\n");
      out.write("\r\n");
      out.write("    //保存\r\n");
      out.write("    function Save() {\r\n");
      out.write("        var detail = [],\r\n");
      out.write("            tbody = $2(\"tbody\");\r\n");
      out.write("        for (var i = 0; i < tbody.rows.length; i++) {\r\n");
      out.write("            var odate = tbody.rows[i].cells[2].childNodes[0].value;\r\n");
      out.write("            var oname = tbody.rows[i].cells[3].childNodes[0].value;\r\n");
      out.write("            var ocontent = tbody.rows[i].cells[4].childNodes[0].value;\r\n");
      out.write("            var ostarttime = tbody.rows[i].cells[5].childNodes[0].value;\r\n");
      out.write("            var oendtime = tbody.rows[i].cells[6].childNodes[0].value;\r\n");
      out.write("            var opeople = tbody.rows[i].cells[7].childNodes[0].value;\r\n");
      out.write("            var oevaluation = tbody.rows[i].cells[8].childNodes[0].value;\r\n");
      out.write("            var oinfo = tbody.rows[i].cells[9].childNodes[0].value;\r\n");
      out.write("            var obelongpro = document.getElementById(\"obelongpro\").value;\r\n");
      out.write("            var item = odate + \"^\" + oname + \"^\" + ocontent + \"^\" + ostarttime + \"^\" + oendtime + \"^\" + opeople + \"^\" + oevaluation + \"^\" + oinfo + \"^\" + obelongpro;\r\n");
      out.write("            detail.push(item);\r\n");
      out.write("        }\r\n");
      out.write("        var detailstr = detail.join(\"|\");\r\n");
      out.write("        $2(\"detail\").value = detailstr;\r\n");
      out.write("        \r\n");
      out.write("        var stddate = document.getElementById(\"startdate\").value;\r\n");
      out.write("        var endate = document.getElementById(\"enddate\").value;\r\n");
      out.write("        var dateTime = new Date();\r\n");
      out.write("        var thisdate = dateTime.format('yyyy-MM-dd');\r\n");
      out.write("        var date1 = dateTime.setFullYear(thisdate.split('-').join(','));\r\n");
      out.write("        var date2 = dateTime.setFullYear(stddate.split('-').join(','));\r\n");
      out.write("        var date3 = dateTime.setFullYear(endate.split('-').join(','));\r\n");
      out.write("        var a1 = thisdate.split(\"-\");\r\n");
      out.write("        var b1 = stddate.split(\"-\");\r\n");
      out.write("        var c1 = endate.split(\"-\");\r\n");
      out.write("        var d1 = new Date(a1[0],a1[1],a1[2]);\r\n");
      out.write("        var d2 = new Date(b1[0],b1[1],b1[2]);\r\n");
      out.write("        var d3 = new Date(c1[0],c1[1],c1[2]);\r\n");
      out.write("        if (obelongpro == \"\")\r\n");
      out.write("        {\r\n");
      out.write("            alert(\"请选择一个项目!\");\r\n");
      out.write("        }\r\n");
      out.write("        else\r\n");
      out.write("        {\r\n");
      out.write("            $.ajax({\r\n");
      out.write("\t\t\t\t   type: \"POST\",\r\n");
      out.write("\t\t\t\t   url: basePath + \"/othercareservicessaveOthercareservices.do?detail=\"+encodeURI(detailstr),\r\n");
      out.write("\t\t\t\t   success:function (msg){\r\n");
      out.write("\t\t\t\t   \t\tvar result = msg;\r\n");
      out.write("\t\t\t\t   \t\tif('success'==result){\r\n");
      out.write("\t\t\t\t   \t\t \talert('新增其他护理服务成功');\r\n");
      out.write("\t\t\t\t   \t\t\twindow.location.href=basePath+\"/othercareserviceslist.do\";\r\n");
      out.write("\t\t\t\t   \t\t}\r\n");
      out.write("\t\t\t\t   \t\telse{\r\n");
      out.write("\t\t\t\t   \t\t\talert('新增其他护理服务失败');\r\n");
      out.write("\t\t\t\t   \t\t}\r\n");
      out.write("\t\t\t\t   },\r\n");
      out.write("\t\t\t\t   failure:function (){\r\n");
      out.write("\t\t\t\t   \t\talert(\"未知错误！\");\r\n");
      out.write("\t\t\t\t   }\t   \r\n");
      out.write("\t\t\t   });\r\n");
      out.write("        }\r\n");
      out.write("    }\r\n");
      out.write("    \r\n");
      out.write("    function chooseElders(){\r\n");
      out.write("\t\t    var mname = \"oname\";\r\n");
      out.write("\t\t    var obj = new Object();\r\n");
      out.write("\t\t    obj.memname=mname;\r\n");
      out.write("\t\t    obj.chooseflag=\"careserve\";\r\n");
      out.write("\t\t    var tab1 = document.getElementById(\"tab\");\r\n");
      out.write("\t\t    var rindex = event.srcElement.parentNode.parentNode.rowIndex;\r\n");
      out.write("\t\t    var url =  basePath + \"/memberlist.do?chooseflag=careserve\";\r\n");
      out.write("\t\t    //window.open(url);\r\n");
      out.write("\t\t    str = window.showModalDialog(url,obj,\"dialogWidth=500px;dialogHeight=400px\");\r\n");
      out.write("\t\t    if(str!=null&&str!='') \r\n");
      out.write("\t\t    \tarr = str.split(\",\");\r\n");
      out.write("\t\t    if(typeof(str)==\"undefined\"){\r\n");
      out.write("\t\t        tab1.rows[rindex].innerText=\"\";\r\n");
      out.write("\t\t    }else if(str==\"nochange\"){\r\n");
      out.write("\t\t        //nothing to do\r\n");
      out.write("\t\t    }else{\r\n");
      out.write("\t\t    \ttab1.rows[rindex].cells[3].innerHTML=\"<input name='oname' type='text' value=\"+arr[1]+\" onclick='chooseElders()' readonly size='22'/>\";\r\n");
      out.write("\t\t    } \t\r\n");
      out.write("\t   } \r\n");
      out.write("</script>\r\n");
      out.write("</head>\r\n");
      out.write("<body>\r\n");
      out.write("<div class=\"topLanBar\"><b>当前位置：</b>护理管理 >介护服务 > 新增其他介护服务记录</div>\r\n");
      out.write("<table width=\"100%\">\r\n");
      out.write("  <tr>\r\n");
      out.write("    <td background=\"");
      out.print(basePath);
      out.write("/pages/train/skins/img/lan-index.gif\">&nbsp;</td>\r\n");
      out.write("  </tr>\r\n");
      out.write("</table>\r\n");
      out.write("<form name=\"myform\"  method=\"post\" action=\"othercareservicessaveOthercareservices.do\">\r\n");
      out.write("<input type=\"hidden\" id=\"detail\" name=\"detail\" />\r\n");
      out.write("<input name=\"startdate\" type=\"hidden\" value=\"\"/>\r\n");
      out.write("<input name=\"enddate\" type=\"hidden\" value=\"\"/>\r\n");
      out.write("<table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">\r\n");
      out.write("<tr>\r\n");
      out.write("<td><button onClick=\"AddRow()\" id=\"001\">增加一行</button><button onClick=\"DelRow()\" id=\"001\">删除</td>\r\n");
      out.write("<td colspan=\"9\" align=\"right\">所属项目:<input type=\"text\" id=\"obelongpro\" name=\"obelongpro\" size=\"18\" onclick=\"choosePro()\" readonly></td>\r\n");
      out.write("</tr>\r\n");
      out.write("</table>\r\n");
      out.write("<table  id=\"tab\" width=\"100%\" border=\"1\" cellpadding=\"3\" cellspacing=\"1\" class=\"tableList\">\r\n");
      out.write("    <tr>\r\n");
      out.write("        <th width=\"4%\" nowrap>序号</th>\r\n");
      out.write("        <th width=\"5%\" nowrap><input type=\"checkbox\" class=\"checkBox1\"  onclick=\"checkAll(this)\" /></th>\r\n");
      out.write("        <th width=\"14%\" nowrap>日期</th>\r\n");
      out.write("        <th width=\"14%\" nowrap>姓名</th>\r\n");
      out.write("        <th width=\"13%\" nowrap>介护服务内容</th>\r\n");
      out.write("        <th width=\"14%\" nowrap>开始时间</th>\r\n");
      out.write("        <th width=\"16%\" nowrap>完成时间</th>\r\n");
      out.write("        <th width=\"19%\" nowrap>执行人员\\单位</th>\r\n");
      out.write("        <th width=\"19%\" nowrap>实施的评价</th>\r\n");
      out.write("        <th width=\"19%\" nowrap>备注</th>\r\n");
      out.write("    </tr>\r\n");
      out.write("    <tbody id=\"tbody\">\r\n");
      out.write("    <tr>\r\n");
      out.write("     <td align=\"center\">1</td>\r\n");
      out.write("     <td align=\"center\"><input type=\"checkbox\" class=\"checkBox1\"  name=\"b_id\" /></td>\r\n");
      out.write("     <td align=\"center\"><input type=\"text\" size=\"22\" name=\"odate\" value=\"\" class=\"Wdate\" onClick=\"WdatePicker({dateFmt:'yyyy-MM-dd',readOnly:true})\" /></td>\r\n");
      out.write("     <td align=\"center\"><input name=\"oname\" type=\"text\" value=\"");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${oname}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
      out.write("\" size=\"22\" onclick=\"chooseElders()\" readonly/></td>\r\n");
      out.write("     <td align=\"center\"><input name=\"ocontent\" type=\"text\" value=\"");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${ocontent}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
      out.write("\" size=\"19\"/></td>\r\n");
      out.write("     <td align=\"center\"><input type=\"text\" size=\"21\" name=ostarttime value=\"\" class=\"Wdate\" onClick=\"WdatePicker({dateFmt:'HH:mm:ss',readOnly:true})\" /></td>\r\n");
      out.write("     <td align=\"center\"><input type=\"text\" size=\"21\" name=\"oendtime\" value=\"\" class=\"Wdate\" onClick=\"WdatePicker({dateFmt:'HH:mm:ss',readOnly:true})\" /></td>\r\n");
      out.write("     <td align=\"center\"><input name=\"opeople\" type=\"text\" value=\"");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${opeople}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
      out.write("\" size=\"19\"/></td>\r\n");
      out.write("     <td align=\"center\"><input name=\"oevaluation\" type=\"text\" value=\"");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${oevaluation}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
      out.write("\" size=\"19\"/></td>\r\n");
      out.write("     <td align=\"center\"><textarea name=\"oinfo\" cols=\"34\" onBlur=\"javascript:this.style.width='186px';this.style.height='21px';\" onFocus=\"javascript:this.style.width='210px';this.style.height='90px';\" rows=\"1\">");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${oinfo}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
      out.write("</textarea></td>\r\n");
      out.write("    </tr>\r\n");
      out.write("    </tbody>\r\n");
      out.write("</table>\r\n");
      out.write("<table width=\"100%\">\r\n");
      out.write("     <tr>\r\n");
      out.write("     <td width=\"100%\" align=\"center\"><button onclick=\"Save()\">提交</button> \r\n");
      out.write("\t\t<button onClick=\"forward('othercareserviceslist.do')\">返回</button></td>\r\n");
      out.write("    </tr>\r\n");
      out.write("</table>\r\n");
      out.write("</form>\r\n");
      out.write("</body>\r\n");
      out.write("</html>\r\n");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
