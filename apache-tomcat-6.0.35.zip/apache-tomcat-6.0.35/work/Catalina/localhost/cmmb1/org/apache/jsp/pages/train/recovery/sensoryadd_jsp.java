package org.apache.jsp.pages.train.recovery;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import java.util.*;
import com.wootion.idp.view.vo.FordNagativation;

public final class sensoryadd_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();

  private static java.util.List _jspx_dependants;

  static {
    _jspx_dependants = new java.util.ArrayList(1);
    _jspx_dependants.add("/pages/train/recovery/../import.jsp");
  }

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.AnnotationProcessor _jsp_annotationprocessor;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_annotationprocessor = (org.apache.AnnotationProcessor) getServletConfig().getServletContext().getAttribute(org.apache.AnnotationProcessor.class.getName());
  }

  public void _jspDestroy() {
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      response.setContentType("text/html; charset=UTF-8");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write('\r');
      out.write('\n');
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");

String path = request.getContextPath();
String basePath = request.getScheme()+"://"+request.getServerName()+":"+request.getServerPort()+path;

      out.write("\r\n");
      out.write("<link href=\"");
      out.print(basePath);
      out.write("/pages/train/skins/css/common.css\" rel=\"stylesheet\" type=\"text/css\" />\r\n");
      out.write("<script type=\"text/javascript\" src=\"");
      out.print(basePath);
      out.write("/js/md5.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\" src=\"");
      out.print(basePath);
      out.write("/js/jquery-1.3.2.min.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\" src=\"");
      out.print(basePath);
      out.write("/pages/train/js/check.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\" src=\"");
      out.print(basePath);
      out.write("/js/My97DatePicker/WdatePicker.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\" src=\"");
      out.print(basePath);
      out.write("/pages/train/js/common.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\" src=\"");
      out.print(basePath);
      out.write("/js/communication.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\" src=\"");
      out.print(basePath);
      out.write("/js/validate.js\"></script>\r\n");
      out.write("\r\n");
      out.write("<html>\r\n");
      out.write("<head>\r\n");
      out.write("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">\r\n");
      out.write("<title>新增感官功能康复记录</title>\r\n");
      out.write("<script type=\"text/javascript\">\r\n");
      out.write("var basePath = '");
      out.print(basePath);
      out.write("';\r\n");
      out.write("var $2 = function(id){\r\n");
      out.write("        return document.getElementById(id);\r\n");
      out.write("    }\r\n");
      out.write("\r\n");
      out.write("    //全选\r\n");
      out.write("    function checkAll(target) {\r\n");
      out.write("        var checkeds = document.getElementsByName(\"b_id\");\r\n");
      out.write("        for (var i = 0; i < checkeds.length; i++) {\r\n");
      out.write("            checkeds[i].checked = target.checked;\r\n");
      out.write("        }\r\n");
      out.write("    }\r\n");
      out.write("\r\n");
      out.write("    //刷新行号\r\n");
      out.write("    function refreshRowNo() {\r\n");
      out.write("        var tbody = $2(\"tbody\");\r\n");
      out.write("        for (var i = 0; i < tbody.rows.length; i++) {\r\n");
      out.write("            tbody.rows[i].cells[0].innerHTML = i + 1;\r\n");
      out.write("        }\r\n");
      out.write("    }\r\n");
      out.write("\r\n");
      out.write("    //添加行\r\n");
      out.write("    function AddRow() {\r\n");
      out.write("        var tbody = $2(\"tbody\");\r\n");
      out.write("        var row = tbody.insertRow(tbody.rows.length);\r\n");
      out.write("        row.insertCell(row.cells.length);\r\n");
      out.write("        row.setAttribute(\"align\",\"center\");\r\n");
      out.write("        row.insertCell(row.cells.length).innerHTML = \"<input type='checkbox' class='checkBox1' name='b_id' />\";\r\n");
      out.write("        row.insertCell(row.cells.length).innerHTML = \"<input type='text' size='21' name='sstarttime' value='' class='Wdate' onClick=\\\"WdatePicker({dateFmt:'HH:mm:ss',readOnly:true})\\\" />\";\r\n");
      out.write("        row.insertCell(row.cells.length).innerHTML = \"<input type='text' size='21' name='sendtime' value='' class='Wdate' onClick=\\\"WdatePicker({dateFmt:'HH:mm:ss',readOnly:true})\\\" />\";\r\n");
      out.write("        row.insertCell(row.cells.length).innerHTML = \"<input type='text' name='sattend' value='");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${sattend}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
      out.write("' size='28'/>\";\r\n");
      out.write("        row.insertCell(row.cells.length).innerHTML = \"<textarea name='sinfo' cols='38' onBlur=\\\"javascript:this.style.width='204px';this.style.height='21px';\\\" onFocus=\\\"javascript:this.style.width='210px';this.style.height='90px';\\\" rows='1'>");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${sinfo}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
      out.write("</textarea>\";\r\n");
      out.write("        row.insertCell(row.cells.length).innerHTML = \"<input type='text' name='swrite' value='");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${swrite}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
      out.write("' size='14'/>\";\r\n");
      out.write("        \r\n");
      out.write("        refreshRowNo();\r\n");
      out.write("    }\r\n");
      out.write("\r\n");
      out.write("    //删除行\r\n");
      out.write("    function DelRow() {\r\n");
      out.write("        var checkeds = document.getElementsByName(\"b_id\");\r\n");
      out.write("        var ischeck = false;\r\n");
      out.write("        for (var i = checkeds.length - 1; i >= 0; i--) {\r\n");
      out.write("            if (checkeds[i].checked) {\r\n");
      out.write("            alert(\"zzzz\"+i);\r\n");
      out.write("                ischeck = true;\r\n");
      out.write("                break;\r\n");
      out.write("            }\r\n");
      out.write("        }\r\n");
      out.write("        if (ischeck) {\r\n");
      out.write("            if (confirm(\"确定删除选中行?\")) {\r\n");
      out.write("                for (var i = checkeds.length - 1; i >= 0; i--) {\r\n");
      out.write("                alert(\"vvvv\"+i);\r\n");
      out.write("                    if (checkeds[i].checked) {\r\n");
      out.write("                        var index = checkeds[i].parentNode.parentNode.rowIndex;\r\n");
      out.write("                        $2(\"tbody\").deleteRow(index - 1);\r\n");
      out.write("                    }\r\n");
      out.write("                }\r\n");
      out.write("                refreshRowNo();\r\n");
      out.write("            }\r\n");
      out.write("        } else {\r\n");
      out.write("            alert(\"请选中需要删除的行!\");\r\n");
      out.write("        }\r\n");
      out.write("    } \r\n");
      out.write("\r\n");
      out.write(" function choosePro(){\r\n");
      out.write("    var pname = \"sbelongpro\";\r\n");
      out.write("    var wWidth = 1040;\r\n");
      out.write("    var wHeight = 510;\r\n");
      out.write("    var wTop = (window.screen.height - wHeight)/2;\r\n");
      out.write("    var wLeft = (window.screen.width - wWidth)/2;\r\n");
      out.write("    var obj = new Object();\r\n");
      out.write("    obj.name=pname;\r\n");
      out.write("    \r\n");
      out.write("    var url =  basePath + \"/proquery.do\";\r\n");
      out.write("    str = window.showModalDialog(url,obj,\"dialogWidth=500px;dialogHeight=400px\"); \r\n");
      out.write("    arr = str.split(\",\");\r\n");
      out.write("    //window.open(url,\"\",\"Height=400px,Width=500px\");\r\n");
      out.write("    if(typeof(str)==\"undefined\"){\r\n");
      out.write("        document.getElementById(pname).value=\"\";\r\n");
      out.write("    }else if(str==\"nochange\"){\r\n");
      out.write("        //document.getElementById(cid).value\r\n");
      out.write("    }else{\r\n");
      out.write("    \tdocument.getElementById(pname).value=arr[0];\r\n");
      out.write("    \tdocument.getElementById(\"startdate\").value=arr[2];\r\n");
      out.write("    \tdocument.getElementById(\"enddate\").value=arr[3];\r\n");
      out.write("    }\r\n");
      out.write("  }  \r\n");
      out.write("\r\n");
      out.write("    Date.prototype.format = function(format)\r\n");
      out.write("\t{\r\n");
      out.write("\t    var o =\r\n");
      out.write("\t    {\r\n");
      out.write("\t        \"M+\" : this.getMonth()+1, //month\r\n");
      out.write("\t        \"d+\" : this.getDate(),    //day\r\n");
      out.write("\t        \"h+\" : this.getHours(),   //hour\r\n");
      out.write("\t        \"m+\" : this.getMinutes(), //minute\r\n");
      out.write("\t        \"s+\" : this.getSeconds(), //second\r\n");
      out.write("\t        \"q+\" : Math.floor((this.getMonth()+3)/3),  //quarter\r\n");
      out.write("\t        \"S\" : this.getMilliseconds() //millisecond\r\n");
      out.write("\t    }\r\n");
      out.write("\t    if(/(y+)/.test(format))\r\n");
      out.write("\t    format=format.replace(RegExp.$1,(this.getFullYear()+\"\").substr(4 - RegExp.$1.length));\r\n");
      out.write("\t    for(var k in o)\r\n");
      out.write("\t    if(new RegExp(\"(\"+ k +\")\").test(format))\r\n");
      out.write("\t    format = format.replace(RegExp.$1,RegExp.$1.length==1 ? o[k] : (\"00\"+ o[k]).substr((\"\"+ o[k]).length));\r\n");
      out.write("\t    return format;\r\n");
      out.write("\t}\r\n");
      out.write("\r\n");
      out.write("    //保存\r\n");
      out.write("    function Save() {\r\n");
      out.write("        var detail = new Array();\r\n");
      out.write("        var times = new Array();\r\n");
      out.write("        var tbody = $2(\"tbody\");\r\n");
      out.write("        for (var i = 0; i < tbody.rows.length; i++) {\r\n");
      out.write("            var sstarttime = tbody.rows[i].cells[2].childNodes[0].value;\r\n");
      out.write("            var sendtime = tbody.rows[i].cells[3].childNodes[0].value;\r\n");
      out.write("            var sattend = tbody.rows[i].cells[4].childNodes[0].value;\r\n");
      out.write("            \r\n");
      out.write("            if(sstarttime==''||sendtime==''){\r\n");
      out.write("                alert('第'+(i+1)+'行时间不能为空');\r\n");
      out.write("                return;\r\n");
      out.write("            }else if(sstarttime>sendtime){\r\n");
      out.write("                alert('第'+(i+1)+'行结束时间必须大于开始时间');\r\n");
      out.write("                return;\r\n");
      out.write("            }\r\n");
      out.write("            times.push(sstarttime+\",\"+sendtime);\r\n");
      out.write("            \r\n");
      out.write("            var sinfo = tbody.rows[i].cells[5].childNodes[0].value;\r\n");
      out.write("            var swrite = tbody.rows[i].cells[6].childNodes[0].value;\r\n");
      out.write("            var sbelongpro = document.getElementById(\"sbelongpro\").value;\r\n");
      out.write("            var item = sstarttime + \"^\" + sendtime + \"^\" + sattend + \"^\" + sinfo + \"^\" + swrite + \"^\" + sbelongpro;\r\n");
      out.write("            detail.push(item);\r\n");
      out.write("        }\r\n");
      out.write("        \r\n");
      out.write("        //判断时间点之间的交错\r\n");
      out.write("        if(!istimeConflict(times)){\r\n");
      out.write("             return;\r\n");
      out.write("        }\r\n");
      out.write("        \r\n");
      out.write("        var detailstr = detail.join(\"|\");\r\n");
      out.write("        $2(\"detail\").value = detailstr;\r\n");
      out.write("        \r\n");
      out.write("        var stddate = document.getElementById(\"startdate\").value;\r\n");
      out.write("        var endate = document.getElementById(\"enddate\").value;\r\n");
      out.write("        var dateTime = new Date();\r\n");
      out.write("        var thisdate = dateTime.format('yyyy-MM-dd');\r\n");
      out.write("        var date1 = dateTime.setFullYear(thisdate.split('-').join(','));\r\n");
      out.write("        var date2 = dateTime.setFullYear(stddate.split('-').join(','));\r\n");
      out.write("        var date3 = dateTime.setFullYear(endate.split('-').join(','));\r\n");
      out.write("        var a1 = thisdate.split(\"-\");\r\n");
      out.write("        var b1 = stddate.split(\"-\");\r\n");
      out.write("        var c1 = endate.split(\"-\");\r\n");
      out.write("        var d1 = new Date(a1[0],a1[1],a1[2]);\r\n");
      out.write("        var d2 = new Date(b1[0],b1[1],b1[2]);\r\n");
      out.write("        var d3 = new Date(c1[0],c1[1],c1[2]);\r\n");
      out.write("        if (sbelongpro == \"\")\r\n");
      out.write("        {\r\n");
      out.write("            alert(\"请选择一个项目!\");\r\n");
      out.write("        }\r\n");
      out.write("        else\r\n");
      out.write("        {\r\n");
      out.write("             $.ajax({\r\n");
      out.write("\t\t\t\t\ttype : \"POST\",\r\n");
      out.write("\t\t\t\t\turl : basePath + \"/sensorysaveSenchology.do?detail=\" + detailstr,\r\n");
      out.write("\t\t\t\t\tsuccess : function(msg) {\r\n");
      out.write("\t\t\t\t\t\tvar result = msg;\r\n");
      out.write("\t\t\t\t\t\tif ('success' == result) {\r\n");
      out.write("\t\t\t\t\t\t\talert('新增康复记录成功');\r\n");
      out.write("\t\t\t\t\t\t\twindow.location.href = basePath + \"/sensorylist.do\";\r\n");
      out.write("\t\t\t\t\t\t} else {\r\n");
      out.write("\t\t\t\t\t\t\talert('新增康复记录失败');\r\n");
      out.write("\t\t\t\t\t\t}\r\n");
      out.write("\t\t\t\t\t},\r\n");
      out.write("\t\t\t\t\tfailure : function() {\r\n");
      out.write("\t\t\t\t\t\talert(\"未知错误！\");\r\n");
      out.write("\t\t\t\t\t}\r\n");
      out.write("\t\t\t\t});\r\n");
      out.write("        }\r\n");
      out.write("    }\r\n");
      out.write("function istimeConflict(times){\r\n");
      out.write("        for (var i = 0; i < times.length-1; i++){\r\n");
      out.write("            for(var j=i+1;j<times.length; j++){\r\n");
      out.write("                 if(times[i].split(',')[0]>times[j].split(',')[1]||times[i].split(',')[1]<times[j].split(',')[0]){\r\n");
      out.write("                       continue;\r\n");
      out.write("                 }else{\r\n");
      out.write("                     alert('第'+(i+1)+'与'+(j+1)+'行时间有冲突');\r\n");
      out.write("                     return false;\r\n");
      out.write("                 }\r\n");
      out.write("            }\r\n");
      out.write("        }\r\n");
      out.write("        return true;\r\n");
      out.write("    }\r\n");
      out.write("</script>\r\n");
      out.write("</head>\r\n");
      out.write("<body>\r\n");
      out.write("<div class=\"topLanBar\"><b>当前位置：</b>康复管理 >康复服务 > 新增感官功能康复记录</div>\r\n");
      out.write("<table width=\"100%\">\r\n");
      out.write("  <tr>\r\n");
      out.write("    <td background=\"");
      out.print(basePath);
      out.write("/pages/train/skins/img/lan-index.gif\">&nbsp;</td>\r\n");
      out.write("  </tr> \r\n");
      out.write("</table>\r\n");
      out.write("<form name=\"myform\" method=\"post\" action=\"sensorysaveSenchology.do\">\r\n");
      out.write("<input type=\"hidden\" id=\"detail\" name=\"detail\" />\r\n");
      out.write("<input name=\"startdate\" type=\"hidden\" value=\"\"/>\r\n");
      out.write("<input name=\"enddate\" type=\"hidden\" value=\"\"/>\r\n");
      out.write("<table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">\r\n");
      out.write("<tr>\r\n");
      out.write("<td><button onClick=\"AddRow()\" id=\"001\">增加一行</button><button onClick=\"DelRow()\" id=\"001\">删除</td>\r\n");
      out.write("<td colspan=\"6\" align=\"right\">所属项目:<input type=\"text\" id=\"sbelongpro\" name=\"sbelongpro\" size=\"10\" readonly onclick=\"choosePro()\"></td>\r\n");
      out.write("</tr>\r\n");
      out.write("</table>\r\n");
      out.write("<table  width=\"100%\" border=\"1\" cellpadding=\"3\" cellspacing=\"1\" class=\"tableList\">\r\n");
      out.write("    <tr>\r\n");
      out.write("        <th width=\"4%\" nowrap>序号</th>\r\n");
      out.write("        <th width=\"5%\" nowrap><input type=\"checkbox\" class=\"checkBox1\"  onclick=\"checkAll(this)\" /></th>\r\n");
      out.write("        <th width=\"14%\" nowrap>开始时间</th>\r\n");
      out.write("        <th width=\"14%\" nowrap>结束时间</th>\r\n");
      out.write("        <th width=\"17%\" nowrap>参加人员</th>\r\n");
      out.write("        <th width=\"21%\" nowrap>活动介绍及备注</th>\r\n");
      out.write("        <th width=\"10%\" nowrap>记录人签字</th>\r\n");
      out.write("    </tr>\r\n");
      out.write("    <tbody id=\"tbody\">\r\n");
      out.write("    <tr>\r\n");
      out.write("     <td align=\"center\">1</td>\r\n");
      out.write("     <td align=\"center\"><input type=\"checkbox\" class=\"checkBox1\"  name=\"b_id\" /></td>\r\n");
      out.write("     <td align=\"center\"><input type=\"text\" size=\"21\" name=\"sstarttime\" value=\"\" class=\"Wdate\" onClick=\"WdatePicker({dateFmt:'HH:mm:ss',readOnly:true})\" /></td>\r\n");
      out.write("     <td align=\"center\"><input type=\"text\" size=\"21\" name=\"sendtime\" value=\"\" class=\"Wdate\" onClick=\"WdatePicker({dateFmt:'HH:mm:ss',readOnly:true})\" /></td>\r\n");
      out.write("     <td align=\"center\"><input type=\"text\" name=\"sattend\" value=\"");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${sattend}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
      out.write("\" size=\"28\"/></td>\r\n");
      out.write("     <td align=\"center\">\r\n");
      out.write("                       <textarea name=\"sinfo\" cols=\"38\" onBlur=\"javascript:this.style.width='202px';this.style.height='21px';\" onFocus=\"javascript:this.style.width='210px';this.style.height='90px';\" rows=\"1\">");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${sinfo}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
      out.write("</textarea>\r\n");
      out.write("     </td>\r\n");
      out.write("     <td align=\"center\"><input type=\"text\" name=\"swrite\" value=\"");
      out.write((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${swrite}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
      out.write("\" size=\"14\"/></td>\r\n");
      out.write("    </tr>\r\n");
      out.write("    </tbody>\r\n");
      out.write("</table>\r\n");
      out.write("<table width=\"100%\">\r\n");
      out.write("     <tr>\r\n");
      out.write("     <td width=\"100%\" align=\"center\"><button onclick=\"Save()\">提交</button> \r\n");
      out.write("\t\t<button onClick=\"forward('sensorylist.do')\">返回</button></td>\r\n");
      out.write("    </tr>\r\n");
      out.write("</table>\r\n");
      out.write("</form>\r\n");
      out.write("</body>\r\n");
      out.write("</html>\r\n");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
